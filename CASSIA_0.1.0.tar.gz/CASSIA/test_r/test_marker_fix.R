# Test script to fix the marker string conversion issue
# This script tests different ways to properly format marker strings for Python

library(CASSIA)
library(reticulate)

# Ensure py_tools is available
if (!exists("py_tools", envir = .GlobalEnv)) {
  py_tools <<- CASSIA:::py_tools
}

# Get test data
markers_unprocessed <- CASSIA::loadExampleMarkers(processed = FALSE)
if (is.factor(markers_unprocessed$cluster)) {
  markers_unprocessed$cluster <- as.character(markers_unprocessed$cluster)
}

# Extract monocyte data
monocyte_data <- markers_unprocessed[markers_unprocessed$cluster == "monocyte", ]
cat("Monocyte rows found:", nrow(monocyte_data), "\n")

# Get the marker string
marker_string <- monocyte_data$markers[1]
cat("Original marker string length:", nchar(marker_string), "\n")
cat("First 100 chars:", substr(marker_string, 1, 100), "\n")

# Test different conversion approaches
cat("\n=== TESTING CONVERSION METHODS ===\n")

# Method 1: Direct string (current problematic method)
cat("\n--- Method 1: Direct string ---\n")
try({
  result1 <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash",
    temperature = 0,
    marker_list = marker_string,
    tissue = "large intestine", 
    species = "human",
    provider = "openrouter"
  )
  cat("Method 1: SUCCESS\n")
}, silent = TRUE)

# Method 2: Convert to Python string explicitly
cat("\n--- Method 2: Explicit Python string conversion ---\n")
try({
  py_string <- reticulate::r_to_py(marker_string)
  result2 <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash",
    temperature = 0,
    marker_list = py_string,
    tissue = "large intestine",
    species = "human", 
    provider = "openrouter"
  )
  cat("Method 2: SUCCESS\n")
}, silent = TRUE)

# Method 3: Split and rejoin to ensure proper format
cat("\n--- Method 3: Split and rejoin ---\n")
try({
  # Split by comma, trim whitespace, rejoin
  genes <- strsplit(marker_string, ",")[[1]]
  genes <- trimws(genes)
  clean_string <- paste(genes, collapse = ", ")
  
  result3 <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash",
    temperature = 0,
    marker_list = clean_string,
    tissue = "large intestine",
    species = "human",
    provider = "openrouter"
  )
  cat("Method 3: SUCCESS\n")
}, silent = TRUE)

# Method 4: Use Python to handle the string
cat("\n--- Method 4: Let Python handle string processing ---\n")
try({
  # Call a Python function that processes the string internally
  result4 <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash", 
    temperature = 0,
    marker_list = as.character(marker_string),
    tissue = "large intestine",
    species = "human",
    provider = "openrouter"
  )
  cat("Method 4: SUCCESS\n")
}, silent = TRUE)

# Method 5: Use character vector instead of string
cat("\n--- Method 5: Character vector ---\n")
try({
  genes_vector <- strsplit(marker_string, ",")[[1]]
  genes_vector <- trimws(genes_vector)
  
  result5 <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash",
    temperature = 0,
    marker_list = genes_vector,
    tissue = "large intestine",
    species = "human",
    provider = "openrouter"
  )
  cat("Method 5: SUCCESS\n")
}, silent = TRUE)

cat("\n=== TESTING COMPLETE ===\n")
cat("Now test with the working method in runCASSIA_batch...\n") 