#!/usr/bin/env python3
"""Test script to demonstrate the split_markers issue with monocyte data"""

import pandas as pd
import sys
import re
import os

# Add the python directory to path
sys.path.append('inst/python')

def split_markers(marker_string):
    """Split markers function from tools_function.py"""
    # First, try splitting by comma and space
    markers = re.split(r',\s*', marker_string)
    
    # If that results in only one marker, try splitting by comma only
    if len(markers) == 1:
        markers = marker_string.split(',')
    
    # If still only one marker, try splitting by space
    if len(markers) == 1:
        markers = marker_string.split()
    
    # Remove any empty strings
    markers = [m.strip() for m in markers if m.strip()]
    
    return markers

def test_monocyte_data():
    """Test the marker splitting with real monocyte data"""
    # Load data
    df = pd.read_csv('inst/extdata/processed.csv')
    monocyte_data = df[df['Broad.cell.type'] == 'monocyte']
    
    if len(monocyte_data) == 0:
        print("No monocyte data found")
        return
    
    marker_string = monocyte_data['Top.Markers'].iloc[0]
    print("=== MONOCYTE MARKER ANALYSIS ===")
    print(f"Original marker string length: {len(marker_string)}")
    print(f"First 200 chars: {marker_string[:200]}")
    print()
    
    # Test split_markers function
    split_result = split_markers(marker_string)
    print("=== AFTER SPLIT_MARKERS ===")
    print(f"Type: {type(split_result)}")
    print(f"Length: {len(split_result)}")
    if len(split_result) > 0:
        print(f"First 5 genes: {split_result[:5]}")
        print(f"Last 5 genes: {split_result[-5:]}")
    print()
    
    # Test correct joining (what should happen)
    joined_correct = ', '.join(split_result)
    print("=== CORRECT JOINING (what should happen) ===")
    print(f"Result (first 200 chars): {joined_correct[:200]}")
    print()
    
    # Test bug case (what actually happens in the validator)
    print("=== BUG CASE (what happens in validator) ===")
    # This simulates when marker_list = [entire_string_as_one_element]
    bug_case_list = [marker_string]  # List with one element containing all genes
    print(f"Bug list type: {type(bug_case_list)}")
    print(f"Bug list length: {len(bug_case_list)}")
    print(f"First element type: {type(bug_case_list[0])}")
    print(f"First element length: {len(bug_case_list[0])}")
    
    # When join is called on this, it joins the CHARACTERS of the string
    bug_joined = ', '.join(bug_case_list[0])  # This joins characters!
    print(f"Bug result (first 100 chars): {bug_joined[:100]}")
    print(f"Bug result looks like: N, K, A, I, N, 3, ,, S, P, P, 1, ...")
    print()
    
    print("=== COMPARISON ===")
    print("Correct approach uses: split_markers() -> list of genes -> join")
    print("Bug case uses: single string -> join characters")
    print()
    print("The validator expects marker_list to be a LIST of gene strings,")
    print("but it's receiving a LIST with ONE string containing all genes.")

if __name__ == "__main__":
    test_monocyte_data() 