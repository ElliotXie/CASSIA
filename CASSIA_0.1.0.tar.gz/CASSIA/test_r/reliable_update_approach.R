# Reliable CASSIA Package Update Script

# This ensures Python modules are properly updated

# Navigate to package root
setwd("D:/newgit/CASSIA/CASSIA_R")

# Clean any previous builds
devtools::clean_dll()

# Update documentation
devtools::document()

# Build and install package
devtools::build()
devtools::install(upgrade = "never")

# Restart R session (recommended)
# .rs.restartR()  # Uncomment in RStudio

# Load the updated package
library(CASSIA)

# Verify Python modules are loaded correctly
check_python_env()

# Test a simple function to confirm updates
markers_test <- loadExampleMarkers(processed = FALSE)
print("Package successfully updated and loaded!") 