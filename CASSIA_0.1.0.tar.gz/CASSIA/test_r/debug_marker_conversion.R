# Debug script for R→Python marker list conversion issue
# This script tests exactly how marker lists are converted and where corruption occurs

# ===== SETUP =====
cat("=== DEBUGGING R→PYTHON MARKER CONVERSION ===\n")

library(CASSIA)
library(reticulate)

# Ensure py_tools is available
if (!exists("py_tools", envir = .GlobalEnv)) {
  py_tools <<- CASSIA:::py_tools
  if (is.null(py_tools)) {
    stop("Failed to access py_tools.")
  }
}

# ===== TEST DATA PREPARATION =====
cat("\n=== PREPARING TEST DATA ===\n")

# Get monocyte data
markers_unprocessed <- CASSIA::loadExampleMarkers(processed = FALSE)
if (is.factor(markers_unprocessed$cluster)) {
  markers_unprocessed$cluster <- as.character(markers_unprocessed$cluster)
}

monocyte_data <- markers_unprocessed[markers_unprocessed$cluster == "monocyte", ]
cat("Monocyte data rows:", nrow(monocyte_data), "\n")

# ===== TEST 1: DIRECT MARKER LIST CONVERSION =====
cat("\n=== TEST 1: DIRECT MARKER LIST CONVERSION ===\n")

# Create a simple test marker list
test_genes <- c("SPP1", "CDH19", "NRXN1", "PLP1", "MYOT")
cat("Original R marker list:\n")
print(test_genes)
cat("Class:", class(test_genes), "\n")
cat("Length:", length(test_genes), "\n")

# Convert to Python using different methods
cat("\n--- Method 1: reticulate::r_to_py() ---\n")
py_genes_1 <- reticulate::r_to_py(test_genes)
cat("Python object type:", class(py_genes_1), "\n")

# Convert back to see what happened
back_to_r_1 <- reticulate::py_to_r(py_genes_1)
cat("Converted back to R:\n")
print(back_to_r_1)

cat("\n--- Method 2: reticulate::r_to_py(convert=TRUE) ---\n")
py_genes_2 <- reticulate::r_to_py(test_genes, convert = TRUE)
cat("Python object type:", class(py_genes_2), "\n")

# Convert back to see what happened
back_to_r_2 <- reticulate::py_to_r(py_genes_2)
cat("Converted back to R:\n")
print(back_to_r_2)

cat("\n--- Method 3: reticulate::r_to_py(convert=FALSE) ---\n")
py_genes_3 <- reticulate::r_to_py(test_genes, convert = FALSE)
cat("Python object type:", class(py_genes_3), "\n")

# Convert back to see what happened
back_to_r_3 <- reticulate::py_to_r(py_genes_3)
cat("Converted back to R:\n")
print(back_to_r_3)

# ===== TEST 2: ACTUAL MONOCYTE GENES CONVERSION =====
cat("\n=== TEST 2: ACTUAL MONOCYTE GENES CONVERSION ===\n")

# Get top genes like the real function does
monocyte_top <- py_tools$get_top_markers(
  df = reticulate::r_to_py(monocyte_data, convert = TRUE),
  n_genes = as.integer(10),  # Use smaller number for testing
  ranking_method = "avg_log2FC"
)

monocyte_top_r <- reticulate::py_to_r(monocyte_top)
gene_col <- names(monocyte_top_r)[2]
actual_genes <- monocyte_top_r[[gene_col]]

cat("Actual monocyte genes (first 10):\n")
print(actual_genes)
cat("Class:", class(actual_genes), "\n")
cat("Length:", length(actual_genes), "\n")

# Test conversion of actual genes
cat("\n--- Converting actual monocyte genes ---\n")
py_actual_1 <- reticulate::r_to_py(actual_genes)
back_actual_1 <- reticulate::py_to_r(py_actual_1)
cat("Method 1 result:\n")
print(back_actual_1)

py_actual_2 <- reticulate::r_to_py(actual_genes, convert = TRUE)
back_actual_2 <- reticulate::py_to_r(py_actual_2)
cat("Method 2 result:\n")
print(back_actual_2)

# ===== TEST 3: CHECK FOR STRING vs FACTOR ISSUES =====
cat("\n=== TEST 3: STRING vs FACTOR vs CHARACTER ISSUES ===\n")

# Test different R data types
test_as_factor <- as.factor(test_genes)
test_as_character <- as.character(test_genes)

cat("As factor:\n")
print(test_as_factor)
cat("Class:", class(test_as_factor), "\n")

cat("As character:\n")
print(test_as_character)
cat("Class:", class(test_as_character), "\n")

# Convert factors
cat("\n--- Converting factor to Python ---\n")
py_factor <- reticulate::r_to_py(test_as_factor)
back_factor <- reticulate::py_to_r(py_factor)
cat("Factor conversion result:\n")
print(back_factor)

# Convert characters
cat("\n--- Converting character to Python ---\n")
py_char <- reticulate::r_to_py(test_as_character)
back_char <- reticulate::py_to_r(py_char)
cat("Character conversion result:\n")
print(back_char)

# ===== TEST 4: SIMULATE THE EXACT runCASSIA CALL =====
cat("\n=== TEST 4: SIMULATE EXACT runCASSIA CALL ===\n")

# Use the exact same process as the working debug script
cat("Testing with first 5 actual monocyte genes...\n")
test_marker_list <- actual_genes[1:5]
cat("Test marker list:\n")
print(test_marker_list)

# Convert exactly as done in the debug script
marker_list_py <- reticulate::r_to_py(test_marker_list, convert = TRUE)

# Create a minimal test function to see what Python receives
cat("\n--- Creating Python test function ---\n")
py_run_string("
def test_marker_reception(marker_list):
    print('Python received marker_list:')
    print(f'Type: {type(marker_list)}')
    print(f'Length: {len(marker_list)}')
    print(f'Contents: {marker_list}')
    
    # Check if it's being interpreted as individual characters
    if len(marker_list) > 10 and all(len(str(item)) <= 2 for item in marker_list[:10]):
        print('WARNING: Appears to be individual characters!')
        print('First 20 items:', marker_list[:20])
    
    return marker_list
")

# Call the test function
cat("\n--- Calling Python test function ---\n")
py_test_result <- py$test_marker_reception(marker_list_py)

# ===== TEST 5: STRING JOINING ISSUES =====
cat("\n=== TEST 5: STRING JOINING ISSUES ===\n")

# Test if it's a string joining issue
test_string <- paste(test_genes, collapse = ", ")
cat("As comma-separated string:\n")
cat("'", test_string, "'\n", sep = "")

py_string <- reticulate::r_to_py(test_string)
back_string <- reticulate::py_to_r(py_string)
cat("String conversion result:\n")
cat("'", back_string, "'\n", sep = "")

# Test if Python is splitting the string
py_run_string("
def test_string_reception(gene_string):
    print(f'Received string: {repr(gene_string)}')
    print(f'Length: {len(gene_string)}')
    
    # Check if it's being split somewhere
    if ',' in gene_string:
        split_genes = gene_string.split(', ')
        print(f'Split into {len(split_genes)} genes:')
        print(split_genes[:5])  # First 5
    
    return gene_string
")

cat("\n--- Testing string reception ---\n")
py$test_string_reception(py_string)

cat("\n=== CONVERSION DEBUG COMPLETED ===\n") 