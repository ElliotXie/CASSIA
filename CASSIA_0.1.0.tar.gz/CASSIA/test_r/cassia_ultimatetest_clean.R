# ============================================================================
# CASSIA Ultimate Test Suite
# ============================================================================
# This file contains comprehensive tests for all CASSIA functionality
# Organized with proper R section headers for VS Code outline support

# ---- SETUP AND CONFIGURATION ----

# Load required libraries
library(devtools)
library(dplyr)
library(reticulate)

# Set working directory to package root
setwd("D:/newgit/CASSIA/CASSIA_R")

# Check if we're in the right directory
if (!file.exists("DESCRIPTION")) {
  stop("Not in package root directory. Please navigate to CASSIA_R folder containing DESCRIPTION file.")
}

# ---- PACKAGE INSTALLATION FUNCTIONS ----

build_local_package <- function() {
  # Clean any previous builds
  devtools::clean_dll()
  
  # Document the package (update NAMESPACE and .Rd files)
  devtools::document()
  
  # Build the package
  devtools::build()
  
  # Install the locally built package
  devtools::install(upgrade = "never")
  
  # Load the package
  library(CASSIA)
  
  # Load example data
  markers_unprocessed <<- loadExampleMarkers(processed = FALSE)
  
  print("✓ Local package built and installed successfully!")
  print("✓ Uncertainty quantification import issues have been fixed!")
}

install_from_github <- function() {
 #devtools::install_github("ElliotXie/CASSIA/CASSIA_R")
  devtools::install_github("ElliotXie/CASSIA/CASSIA_R", ref = "dev_refactor",force=TRUE)
  
  library(CASSIA)
  library(dplyr)
  library(reticulate)
  
  markers_unprocessed <<- loadExampleMarkers(processed = FALSE)
  
  # Get unique cluster names in their original order
  cluster_levels <- unique(markers_unprocessed$cluster)
  # Re-factor the cluster column using these levels
  markers_unprocessed$cluster <<- factor(markers_unprocessed$cluster, levels = cluster_levels, labels = seq_along(cluster_levels))
}

hot_swap_python_files <- function() {
  # Install package first
  devtools::install_github("ElliotXie/CASSIA/CASSIA_R")
  
  packagePath <- find.package("CASSIA")
  
  # Copy all Python modules to the installed package
  python_files <- c(
    "tools_function.py",
    "main_function_code.py", 
    "annotation_boost.py",
    "subclustering.py",
    "Uncertainty_quantification.py",
    "merging_annotation_code.py",
    "cell_type_comparison.py",
    "llm_utils.py",
    "generate_comparison.py"
  )
  
  for (file in python_files) {
    pythonScriptPath <- file.path(packagePath, "python", file)
    file.copy(paste0("D:/newgit/CASSIA/CASSIA_R/inst/python/", file), pythonScriptPath, overwrite = TRUE)
  }
  
  detach("package:CASSIA", unload = TRUE)
  library(CASSIA)
  
  print("✓ Python files hot-swapped successfully!")
}

# ---- DEFAULT API TESTS ----

# ---- SETUP FUNCTIONS ----

setup_standard_environment <- function() {
  build_local_package()
  setwd("D:/newgit/CASSIA/CASSIA_R/test_r")
  print("✓ Standard environment configured!")
}


setup_standard_environment()

# ---- CORE FUNCTIONALITY TESTS ----

test_pipeline <- function() {
  # Test the CASSIA pipeline in fast mode
  fast_results <- runCASSIA_pipeline(
    output_file_name = "TEST2",
    tissue = "large intestine",
    species = "human",
    marker = markers_unprocessed,
    max_workers = 6,
    score_threshold = 92
  )
  
  print("✓ Pipeline test completed")
}

test_batch_annotation <- function() {
  runCASSIA_batch(
    marker = markers_unprocessed,
    output_name = "my_annotation2",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    n_genes = 50,
    provider = "openrouter",
    model = "google/gemini-2.5-flash-preview"
  )
  
  print("✓ Batch annotation test completed")
}

test_merge_annotations <- function() {
  runCASSIA_merge_annotations(
    csv_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full.csv",
    provider = "openrouter",
    model = "deepseek/deepseek-chat-v3-0324",
    detail_level = "detailed",
    process_all = TRUE,
    debug = FALSE
  )
  
  print("✓ Merge annotations test completed")
}

test_scoring <- function() {
  quality_scores <- runCASSIA_score_batch(
    input_file = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full.csv",
    output_file = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full_scored.csv"
  )
  
  # Generate quality report
  runCASSIA_generate_score_report(
    csv_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full_scored.csv",
    output_name = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full_scored_report.csv"
  )
  
  print("✓ Scoring test completed")
}

# ---- SPECIALIZED ANALYSIS TESTS ----

test_subclustering <- function() {
  marker_sub <- loadExampleMarkers_subcluster()
  
  runCASSIA_subclusters(
    marker = marker_sub,
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results",
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter"
  )
  
  print("✓ Subclustering test completed")
}

test_cell_type_comparison <- function() {
  marker <- "IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1, AC026369.3, IGHV3-23, IGKV4-1, IGKV1-5, IGHA1, IGLV3-1, IGLV2-11, MYL2, MZB1, IGHG3, IGHV3-74, IGHM, ANKRD36BP2, AMPD1, IGKV3-20, IGHA2, DERL3, AC104699.1, LINC02362, AL391056.1, LILRB4, CCL3, BMP6, UBE2QL1, LINC00309, AL133467.1, GPRC5D, FCRL5, DNAAF1, AP002852.1, AC007569.1, CXorf21, RNU1-85P, U62317.4, TXNDC5, LINC02384, CCR10, BFSP2, APOBEC3A, AC106897.1"
  
  compareCelltypes(
    tissue = "large intestine",
    celltypes = c("Plasma Cells", "IgA-secreting Plasma Cells", "IgG-secreting Plasma Cells", "IgM-secreting Plasma Cells"),
    marker = marker,
    species = "human",
    output_file = "plasma_cell_subtype"
  )
  
  print("✓ Cell type comparison test completed")
}

# ---- ADVANCED ANALYSIS TESTS ----

test_uncertainty_quantification <- function() {
  # Batch N Times Test
  iteration_results <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed,
    output_name = "my_annotation",
    model = "meta-llama/llama-4-maverick",
    provider = "openrouter",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    batch_max_workers = 3
  )
  
  # Similarity Scoring Test
  similarity_scores <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "C:/Users/ellio/OneDrive - UW-Madison/CASSIA+/CASSIA_Uncertainty_gemini_*_full.csv",
    output_name = "intestine_similarity_test6",
    max_workers = 6,
    provider = "openrouter",
    model = "google/gemini-2.5-flash-preview"
  )
  
  print("✓ Uncertainty quantification tests completed")
}

test_annotation_boost <- function() {
  cluster_info <- "Human Large Intestine"
  target_cluster <- "monocyte"
  
  # Basic Annotation Boost
  runCASSIA_annotationboost(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full.csv",
    marker = markers_unprocessed,
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    output_name = "monocyte_report",
    num_iterations = 5,
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter"
  )
  
  # Annotation Boost with Additional Task
  runCASSIA_annotationboost_additional_task(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation2_full.csv",
    marker = markers_unprocessed,
    output_name = "monocyte_annotationboost",
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    num_iterations = 5,
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter",
    additional_task = "check if this is monocyte"
  )
  
  print("✓ Annotation boost tests completed")
}

# ---- STANDARD TEST RUNNER ----

run_all_standard_tests <- function() {
  print("🚀 Running all standard tests...")
  
  # Setup
  setup_standard_environment()
  
  # Core functionality
  test_pipeline()
  test_batch_annotation()
  test_merge_annotations()
  test_scoring()
  
  # Specialized analysis
  test_subclustering()
  test_cell_type_comparison()
  
  # Advanced analysis
  test_uncertainty_quantification()
  test_annotation_boost()
  
  print("✅ All standard tests completed!")
}

run_all_standard_tests()

# ---- CUSTOMIZED MODEL TESTS ----

# ---- DEEPSEEK API CONFIGURATION ----

setup_deepseek_api <- function() {
  custom_base_url <<- "https://api.deepseek.com"
  custom_model <<- "deepseek-chat"
  
  # Set working directory for test outputs
  setwd("D:/newgit/CASSIA/CASSIA_R/test_r")
  
  # Set API key using the standard approach
  setLLMApiKey("sk-f7c54e95a5e040589f41d83553b55861", provider = custom_base_url)
  
  print("🔧 DeepSeek API configured successfully!")
  print(paste("Base URL:", custom_base_url))
  print(paste("Model:", custom_model))
}

# ---- CUSTOM MODEL CORE TESTS ----

test_custom_batch_annotation <- function() {
  runCASSIA_batch(
    marker = markers_unprocessed,
    output_name = "my_annotation_custom",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    n_genes = 50,
    provider = custom_base_url,
    model = custom_model,
    temperature = 0
  )
  
  print("✓ Custom batch annotation test completed")
}

test_custom_pipeline <- function() {
  runCASSIA_pipeline(
    output_file_name = "TEST_CUSTOM",
    tissue = "large intestine",
    species = "human",
    marker = markers_unprocessed,
    max_workers = 4,
    annotation_model = custom_model,
    annotation_provider = custom_base_url,
    score_model = custom_model,
    score_provider = custom_base_url,
    annotationboost_model = custom_model,
    annotationboost_provider = custom_base_url,
    merge_model = custom_model,
    score_threshold = 75
  )
  
  print("✓ Custom pipeline test completed")
}

test_custom_scoring <- function() {
  quality_scores_custom <- runCASSIA_score_batch(
    input_file = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_full.csv",
    output_file = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_scored.csv",
    model = custom_model,
    provider = custom_base_url,
    max_workers = 4
  )
  
  # Generate quality report for custom model results
  runCASSIA_generate_score_report(
    csv_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_scored.csv",
    output_name = "D:/newgit/CASSIA/CASSIA_R/test_r/custom_model_report"
  )
  
  print("✓ Custom scoring test completed")
}

# ---- CUSTOM MODEL SPECIALIZED TESTS ----

test_custom_subclustering <- function() {
  marker_sub <- loadExampleMarkers_subcluster()
  
  runCASSIA_subclusters(
    marker = marker_sub,
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results_custom",
    model = custom_model,
    provider = custom_base_url,
    temperature = 0
  )
  
  print("✓ Custom subclustering test completed")
}

test_custom_cell_comparison <- function() {
  marker <- "IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1"
  
  # Test with custom model list for comparison
  custom_model_list <- c(custom_model, "backup-model-name")
  
  compareCelltypes(
    tissue = "large intestine",
    celltypes = c("Plasma Cells", "IgA-secreting Plasma Cells", "IgG-secreting Plasma Cells", "IgM-secreting Plasma Cells"),
    marker = marker,
    species = "human",
    model_list = custom_model_list,
    output_file = "plasma_cell_subtype_custom"
  )
  
  print("✓ Custom cell comparison test completed")
}

# ---- CUSTOM MODEL ADVANCED TESTS ----

test_custom_uncertainty_quantification <- function() {
  # Custom Batch N Times
  iteration_results_custom <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed,
    output_name = "my_annotation_custom_uncertainty",
    model = custom_model,
    provider = custom_base_url,
    tissue = "large intestine",
    species = "human",
    max_workers = 4,
    batch_max_workers = 2,
    temperature = 0
  )
  
  # Custom Similarity Scoring
  similarity_scores_custom <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_uncertainty_*_full.csv",
    output_name = "intestine_similarity_custom",
    max_workers = 4,
    provider = custom_base_url,
    model = custom_model
  )
  
  print("✓ Custom uncertainty quantification tests completed")
}

test_custom_annotation_boost <- function() {
  cluster_info <- "Human Large Intestine"
  target_cluster <- "monocyte"
  
  # Custom Basic Annotation Boost
  runCASSIA_annotationboost(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_full.csv",
    marker = markers_unprocessed,
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    output_name = "monocyte_report_custom",
    num_iterations = 3,
    model = custom_model,
    provider = custom_base_url,
    temperature = 0
  )
  
  # Custom Annotation Boost with Additional Task
  runCASSIA_annotationboost_additional_task(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_full.csv",
    marker = markers_unprocessed,
    output_name = "monocyte_boost_custom",
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    num_iterations = 3,
    model = custom_model,
    provider = custom_base_url,
    additional_task = "check if this is a monocyte and assess confidence",
    temperature = 0
  )
  
  print("✓ Custom annotation boost tests completed")
}

# ---- PARAMETER TESTING ----

test_temperature_variations <- function() {
  temperature_tests <- c(0, 0.3, 0.7, 1.0)
  
  for (temp in temperature_tests) {
    tryCatch({
      print(paste("Testing temperature:", temp))
      
      runCASSIA(
        model = custom_model,
        temperature = temp,
        marker_list = c("CD14", "CD68", "CSF1R", "CX3CR1", "CD163"),
        tissue = "large intestine",
        species = "human",
        additional_info = paste("Temperature test:", temp),
        provider = custom_base_url
      )
      
      print(paste("✓ Temperature", temp, "test completed"))
      
    }, error = function(e) {
      print(paste("✗ Temperature", temp, "test failed:", e$message))
    })
  }
  
  print("✓ Temperature variation tests completed")
}

test_multiple_endpoints <- function() {
  # Test with multiple custom endpoints for redundancy
  custom_endpoints <- list(
    primary = list(base_url = "http://localhost:11434", model = "llama3.2:latest"),
    secondary = list(base_url = "http://localhost:8080", model = "mistral:latest"),
    tertiary = list(base_url = "https://api.your-custom-service.com/v1", model = "custom-model-v2")
  )
  
  # Test with primary custom endpoint
  print("Testing with primary custom endpoint...")
  tryCatch({
    runCASSIA_batch(
      marker = markers_unprocessed[1:3, ],  # Small subset for testing
      output_name = "test_primary_custom",
      tissue = "large intestine",
      species = "human",
      max_workers = 2,
      n_genes = 20,
      provider = custom_endpoints$primary$base_url,
      model = custom_endpoints$primary$model,
      temperature = 0.1
    )
    print("✓ Primary custom endpoint test completed")
  }, error = function(e) {
    print(paste("✗ Primary custom endpoint failed:", e$message))
  })
}

# ---- CUSTOM MODEL TEST RUNNER ----

run_all_custom_tests <- function() {
  print("🚀 Running all custom model tests...")
  
  # Setup custom API
  setup_deepseek_api()
  
  # Core functionality
  test_custom_batch_annotation()
  test_custom_pipeline()
  test_custom_scoring()
  
  # Specialized analysis
  test_custom_subclustering()
  test_custom_cell_comparison()
  
  # Advanced analysis
  test_custom_uncertainty_quantification()
  test_custom_annotation_boost()
  
  # Parameter testing
  test_temperature_variations()
  test_multiple_endpoints()
  
  print("✅ All custom model tests completed!")
}

# ---- MASTER TEST RUNNERS ----

# ---- QUICK TESTS ----

quick_test <- function() {
  build_local_package()
  test_batch_annotation()
  print("✅ Quick test completed!")
}

quick_custom_test <- function() {
  setup_deepseek_api()
  test_custom_batch_annotation()
  print("✅ Quick custom test completed!")
}

# ---- FULL TEST SUITES ----

full_test_suite <- function() {
  run_all_standard_tests()
  run_all_custom_tests()
  print("🎉 FULL TEST SUITE COMPLETED! 🎉")
}

# ---- SUMMARY FUNCTION ----

print_test_summary <- function() {
  print("🎯 CASSIA Test Suite Summary:")
  print("------------------------------")
  print("📋 Available Test Functions:")
  print("")
  print("Standard API Tests:")
  print("  • run_all_standard_tests() - Full standard test suite")
  print("  • quick_test() - Quick standard test")
  print("")
  print("Custom Model Tests:")
  print("  • run_all_custom_tests() - Full custom model test suite") 
  print("  • quick_custom_test() - Quick custom test")
  print("")
  print("Master Functions:")
  print("  • full_test_suite() - Run everything")
  print("  • print_test_summary() - Show this summary")
} 