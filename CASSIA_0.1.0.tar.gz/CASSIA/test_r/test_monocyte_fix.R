# Test script to verify the monocyte validator fix
# This tests the specific case that was failing before

library(CASSIA)

cat("=== TESTING MONOCYTE FIX ===\n")

# Load data
markers_unprocessed <- CASSIA::loadExampleMarkers(processed = FALSE)
if (is.factor(markers_unprocessed$cluster)) {
  markers_unprocessed$cluster <- as.character(markers_unprocessed$cluster)
}

# Extract just monocyte for testing
monocyte_data <- markers_unprocessed[markers_unprocessed$cluster == "monocyte", ]
cat("Found", nrow(monocyte_data), "monocyte rows\n")

# Test the individual runCASSIA function (this should now work)
cat("\n=== Testing individual runCASSIA with monocyte ===\n")
if (exists("py_tools") && !is.null(py_tools)) {
  try({
    result <- py_tools$runCASSIA(
      model = "google/gemini-2.5-flash",
      temperature = 0,
      marker_list = monocyte_data$markers[1],
      tissue = "large intestine",
      species = "human",
      provider = "openrouter"
    )
    
    cat("✅ SUCCESS! Monocyte analysis completed without validator errors.\n")
    cat("Result:\n")
    cat("  Main cell type:", result[[1]]$main_cell_type, "\n")
    cat("  Sub cell types:", paste(result[[1]]$sub_cell_types, collapse = ", "), "\n")
    
  }, silent = FALSE)
} else {
  cat("py_tools not available. Please ensure CASSIA is loaded properly.\n")
}

cat("\n=== Testing batch analysis (should now work for monocyte) ===\n")
try({
  # Test with just a small subset including monocyte
  test_data <- markers_unprocessed[1:2, ]  # First two clusters including monocyte
  
  runCASSIA_batch(
    marker = test_data,
    output_name = "test_monocyte_fix",
    tissue = "large intestine",
    species = "human",
    max_workers = 1,  # Use single worker for easier debugging
    n_genes = 50,
    provider = "openrouter",
    model = "google/gemini-2.5-flash"
  )
  
  cat("✅ SUCCESS! Batch analysis completed without monocyte validator errors.\n")
  
}, silent = FALSE)

cat("\n=== Test completed ===\n") 