

library(devtools)
library(dplyr)
library(reticulate)
library(CASSIA)
setwd("D:/newgit/CASSIA/CASSIA_R/test_r")
devtools::install_github("ElliotXie/CASSIA/CASSIA_R", ref = "dev_refactor")
devtools::install_github("ElliotXie/CASSIA/CASSIA_R", ref = "main")
install.packages('Seurat')
setup_cassia_env()


# Core Testing Functions

## Test Pipeline
markers_unprocessed <- loadExampleMarkers(processed = FALSE)

# Run the CASSIA pipeline in fast mode
fast_results <- runCASSIA_pipeline(
    output_file_name = "TEST22",
    tissue = "large intestine",
    species = "human",
    marker = markers_unprocessed,
    max_workers = 6,
    score_threshold = 96
)



fast_results <- py_tools$runCASSIA_pipeline(
    output_file_name = "TEST1",
    tissue = "large intestine",
    species = "human",
    marker = markers_unprocessed,  # Now accepts DataFrame directly
    score_model = "deepseek/deepseek-chat-v3-0324",
    score_provider = "openrouter",
    max_workers = 6,
    score_threshold = 95
)

## Test Batch Annotation

runCASSIA_batch(
    # Required parameters
    marker = markers_unprocessed,                    # Marker data (data frame or file path)
    output_name = "D:/newgit/CASSIA/CASSIA_R/test_r/testcsv",       # Base name for output files
    tissue = "large intestine",                    # Tissue type
    species = "human",                   # Species
    max_workers = 6,    # Number of parallel workers
    n_genes = 50,                        # Number of top marker genes to use
    provider = "openrouter",
    model="gemini",
    validator_involvement = "v1",
    temperature = 0
)

runCASSIA_batch(
    # Required parameters
    marker = markers_unprocessed,                    # Marker data (data frame or file path)
    output_name = "C:/Users/ellio/OneDrive - UW-Madison/Revision_cassia/3_csscore/cs_results/my_annotationnew3_gpt4o",       # Base name for output files
    tissue = "large intestine",                    # Tissue type
    species = "human",                   # Species
    # Optional parameters
    max_workers = 6,    # Number of parallel workers
    n_genes = 50,                        # Number of top marker genes to use
    provider = "openai",
    model="gpt-4o-2024-05-13",
    validator_involvement = "v1",
    temperature = 0
)

iteration_results <- runCASSIA_batch_n_times(
    n = 5,
    marker = markers_unprocessed,
    output_name = "my_annotation_gpt4o_temp1",
    model = "gpt-4o-2024-05-13",
    provider = "openai",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    batch_max_workers = 3,
    temperature = 1,
    validator_involvement = "v1"
)






## Test Merge Annotations

runCASSIA_merge_annotations( csv_path = "D:/newgit/CASSIA/CASSIA_R/my_annotation21231231_full.csv",
                             provider = "openrouter",
                             model = "google/gemini-2.5-flash",
                             detail_level = "all",
                             debug = FALSE)

## Test Scoring

quality_scores <- runCASSIA_score_batch(
  input_file = "D:/newgit/CASSIA/CASSIA_R/my_annotation21231231_full.csv",
  output_file = "D:/newgit/CASSIA/CASSIA_R/my_annotation21231231_full_scored.csv"
)




## Generate quality report
runCASSIA_generate_score_report(
  csv_path = "D:/newgit/CASSIA/CASSIA_R/my_annotation21231231_full_scored.csv",
  output_name = "D:/newgit/CASSIA/CASSIA_R/my_annotation21231231_full_scored_report.csv"
)

## Test Subcluster
marker_sub=loadExampleMarkers_subcluster()

runCASSIA_subclusters(marker = marker_sub,
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results",
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter")



## Test Compare Celltype
marker="IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1, AC026369.3, IGHV3-23, IGKV4-1, IGKV1-5, IGHA1, IGLV3-1, IGLV2-11, MYL2, MZB1, IGHG3, IGHV3-74, IGHM, ANKRD36BP2, AMPD1, IGKV3-20, IGHA2, DERL3, AC104699.1, LINC02362, AL391056.1, LILRB4, CCL3, BMP6, UBE2QL1, LINC00309, AL133467.1, GPRC5D, FCRL5, DNAAF1, AP002852.1, AC007569.1, CXorf21, RNU1-85P, U62317.4, TXNDC5, LINC02384, CCR10, BFSP2, APOBEC3A, AC106897.1"



results <- symphonyCompare(
  tissue = "large intestine",
  celltypes = c("Plasma Cells","IgA-secreting Plasma Cells","IgG-secreting Plasma Cells","IgM-secreting Plasma Cells"),
  marker_set = marker,
  species = "human"
)


## Test CS Score

iteration_results <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed,
    output_name = "my_annotation",
    model = "meta-llama/llama-4-maverick",
    provider = "openrouter",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    batch_max_workers = 3
)


similarity_scores <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "C:/Users/ellio/OneDrive - UW-Madison/CASSIA+/CASSIA_Uncertainty_gemini_*_full.csv", # The file pattern of the uncertainty results
    output_name = "intestine_similarity_test6",
    max_workers = 6,
    provider = "openrouter",
    model = "google/gemini-2.5-flash-preview",
)

similarity_scores <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "C:/Users/ellio/OneDrive - UW-Madison/CASSIA+/CASSIA_Uncertainty_gemini_*_full.csv", # The file pattern of the uncertainty results
    output_name = "intestine_similarity_test3",
    max_workers = 6,
    provider = "openai",
    model = "gpt-4o-mini",
)

## Test Annotation Boost

cluster_info <- "Human Large Intestine"

#Specify the cluster you want to validate
target_cluster = "monocyte"


runCASSIA_annotationboost(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_014335/01_annotation_results/TEST22_FINAL_RESULTS.csv",
    marker = markers_unprocessed,
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    output_name = "monocyte_report",
    num_iterations = 5, # Number of validation rounds
    model ="google/gemini-2.5-flash-preview",
    provider = "openrouter"
)


runCASSIA_annotationboost_additional_task(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_014335/01_annotation_results/TEST22_FINAL_RESULTS.csv",
    marker = markers_unprocessed,
    output_name="monocyte_annotationboost",
    cluster_name = "monocyte",
    major_cluster_info = "Human Large Intestine",
    num_iterations = 5,
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter",
    additional_task = "check if this is monocyte"
)

# Custom Model Testing

setup_deepseek_api <- function() {
  custom_base_url <<- "https://api.deepseek.com"
  custom_model <<- "deepseek-chat"
  
  # Set working directory for test outputs
  setwd("D:/newgit/CASSIA/CASSIA_R/test_r")
  
  # Set API key using the standard approach
  setLLMApiKey("xxx", provider = custom_base_url)
  
  
  print("🔧 DeepSeek API configured successfully!")
  print(paste("Base URL:", custom_base_url))
  print(paste("Model:", custom_model))
}

setup_deepseek_api()

### Test runCASSIA_batch with custom model

setwd("D:/newgit/CASSIA/CASSIA_R/test_r")

runCASSIA_batch(
    # Required parameters
    marker = markers_unprocessed,
    output_name = "my_annotation_custom2",
    tissue = "large intestine",
    species = "human",
    # Custom model parameters
    max_workers = 6,
    n_genes = 50,
    provider = custom_base_url,  # Use HTTP endpoint as provider
    model = custom_model,        # Custom model name
    temperature = 0
)

### Test the pipeline with custom model

# Run the CASSIA pipeline with custom models
runCASSIA_pipeline(
    output_file_name = "TEST_CUSTOM2",
    tissue = "large intestine", 
    species = "human",
    marker = markers_unprocessed,
    max_workers = 4,
    # Custom annotation model
    annotation_model = custom_model,
    annotation_provider = custom_base_url,
    # Custom scoring model  
    score_model = custom_model,
    score_provider = custom_base_url,
    # Custom annotation boost model
    annotationboost_model = custom_model,
    annotationboost_provider = custom_base_url,
    # Custom merge model
    merge_model = custom_model,
    score_threshold = 75
)

### Test the merge with custom model

runCASSIA_merge_annotations(
    csv_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_014335/01_annotation_results/TEST22_FINAL_RESULTS.csv",
    provider = custom_base_url,
    model = custom_model,
    detail_level = "all"
)

### Test the scoring with custom model

quality_scores_custom <- runCASSIA_score_batch(
    input_file = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_014335/01_annotation_results/TEST22_FINAL_RESULTS.csv",
    output_file = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_014335/01_annotation_results/TEST22_FINAL_RESULTS_scored.csv",
    model = custom_model,
    provider = custom_base_url,
    max_workers = 4
)

# Generate quality report for custom model results
runCASSIA_generate_score_report(
    csv_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_100848/01_annotation_results/TEST_CUSTOM2_FINAL_RESULTS.csv",
    output_name = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_100848/01_annotation_results/TEST_CUSTOM2_FINAL_RESULTS_scored_report"
)

### Test subcluster with custom model

marker_sub <- loadExampleMarkers_subcluster()

runCASSIA_subclusters(
    marker = marker_sub,
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results_custom2",
    model = custom_model,
    provider = custom_base_url,
    temperature = 0
)

### Test compare celltype with custom model

marker <- "IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1, AC026369.3, IGHV3-23, IGKV4-1, IGKV1-5, IGHA1, IGLV3-1, IGLV2-11, MYL2, MZB1, IGHG3, IGHV3-74, IGHM, ANKRD36BP2, AMPD1, IGKV3-20, IGHA2, DERL3, AC104699.1, LINC02362, AL391056.1, LILRB4, CCL3, BMP6, UBE2QL1, LINC00309, AL133467.1, GPRC5D, FCRL5, DNAAF1, AP002852.1, AC007569.1, CXorf21, RNU1-85P, U62317.4, TXNDC5, LINC02384, CCR10, BFSP2, APOBEC3A, AC106897.1"


custom_model_list <- c(custom_model, "backup-model-name")

compareCelltypes(
    tissue = "large intestine",
    celltypes = c("Plasma Cells", "IgA-secreting Plasma Cells", "IgG-secreting Plasma Cells", "IgM-secreting Plasma Cells"),
    marker = marker,
    species = "human",
    model_list = custom_model_list,
    output_file = "plasma_cell_subtype_custom"
)

### Test uncertainty quantification with custom model

# Test batch n times with custom model
iteration_results_custom <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed,
    output_name = "my_annotation_custom_uncertainty2",
    model = custom_model,
    provider = custom_base_url,
    tissue = "large intestine",
    species = "human",
    max_workers = 4,
    batch_max_workers = 2,
    temperature = 0
)

# Test similarity scoring with custom model
similarity_scores_custom <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "D:/newgit/CASSIA/CASSIA_R/test_r/my_annotation_custom_uncertainty2_*_full.csv",
    output_name = "intestine_similarity_custom2",
    max_workers = 4,
    provider = custom_base_url,
    model = custom_model
)

### Test annotation boost with custom model


cluster_info <- "Human Large Intestine"
target_cluster <- "monocyte"


runCASSIA_annotationboost(
    full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_100848/01_annotation_results/TEST_CUSTOM2_FINAL_RESULTS.csv",
    marker = markers_unprocessed,
    cluster_name = target_cluster,
    major_cluster_info = cluster_info,
    output_name = "monocyte_report_custom",
    num_iterations = 3,  # Reduced for testing
    model = custom_model,
    provider = custom_base_url,
    temperature = 0,
    search_strategy ="depth"
)



runCASSIA_annotationboost_additional_task(
      full_result_path = "D:/newgit/CASSIA/CASSIA_R/test_r/CASSIA_large_intestine_human_20250708_100848/01_annotation_results/TEST_CUSTOM2_FINAL_RESULTS.csv",
      marker = markers_unprocessed,
      output_name = "monocyte_boost_custom",
      cluster_name = target_cluster,
      major_cluster_info = cluster_info,
      num_iterations = 3,  # Reduced for testing
    model = custom_model,
    provider = custom_base_url,
    additional_task = "check if this is a schwann cell and assess confidence",
    temperature = 0,
    search_strategy ="depth"
)


### Custom Model Configuration Summary

print("🎯 Custom Model Testing Summary:")
print("==================================")
print(paste("Base URL:", custom_base_url))
print(paste("Model:", custom_model))
print("")
print("Tested Functions:")
print("✓ runCASSIA_batch")
print("✓ runCASSIA_pipeline") 
print("✓ runCASSIA_merge_annotations")
print("✓ runCASSIA_score_batch")
print("✓ runCASSIA_subclusters")
print("✓ compareCelltypes")
print("✓ runCASSIA_batch_n_times")
print("✓ runCASSIA_similarity_score_batch")
print("✓ runCASSIA_annotationboost")
print("✓ runCASSIA_annotationboost_additional_task")
print("")
print("📁 Output files generated with '_custom' suffix")
print("🔧 All functions tested with custom HTTP endpoint")

```{r main_test_execution_chunk, echo=TRUE}
# This R chunk will now manage the execution of all tests through function calls.

# Load essential libraries
# Ensure these are loaded before any CASSIA functions are called.
print("Loading required libraries: CASSIA, dplyr, reticulate")
library(CASSIA)
library(dplyr)
library(reticulate)
print("✓ Libraries loaded.")
cat("\n")

# Load and prepare data for core tests
print("Loading and preparing data for core tests...")
# Ensure CASSIA namespace is used if functions are not exported or to be explicit
markers_unprocessed <- CASSIA::loadExampleMarkers(processed = FALSE)
# Get unique cluster names in their original order
# cluster_levels <- unique(markers_unprocessed$cluster)
# Re-factor the cluster column using these levels
# markers_unprocessed$cluster <- factor(markers_unprocessed$cluster, levels = cluster_levels, labels = seq_along(cluster_levels))

marker_sub <- CASSIA::loadExampleMarkers_subcluster()
print("✓ Core test data loaded globally: 'markers_unprocessed' and 'marker_sub'.")
cat("\n")

# Set working directory for test outputs
# This path needs to exist, and the script needs write permissions.
target_wd <- "D:/newgit/CASSIA/CASSIA_R/test_r"
print(paste("Setting working directory for tests to:", target_wd))
if (!dir.exists(target_wd)) {
  print(paste("Warning: Target working directory", target_wd, "does not exist. Will attempt to create it."))
  dir.create(target_wd, recursive = TRUE, showWarnings = TRUE)
}
setwd(target_wd)
print(paste("Current working directory:", getwd()))
cat("\n")

# --- Running Core Tests ---
print("--- STARTING CORE TESTS ---")
if(exists("test_core_pipeline", mode = "function")) test_core_pipeline() else print("test_core_pipeline not found")
if(exists("test_core_batch_annotation", mode = "function")) test_core_batch_annotation() else print("test_core_batch_annotation not found")
if(exists("test_core_merge_annotations", mode = "function")) test_core_merge_annotations() else print("test_core_merge_annotations not found")
if(exists("test_core_scoring", mode = "function")) test_core_scoring() else print("test_core_scoring not found")
if(exists("test_core_generate_score_report", mode = "function")) test_core_generate_score_report() else print("test_core_generate_score_report not found")
if(exists("test_core_subcluster", mode = "function")) test_core_subcluster() else print("test_core_subcluster not found")
if(exists("test_core_compare_celltypes", mode = "function")) test_core_compare_celltypes() else print("test_core_compare_celltypes not found")
if(exists("test_core_batch_n_times", mode = "function")) test_core_batch_n_times() else print("test_core_batch_n_times not found")
if(exists("test_core_similarity_score_batch", mode = "function")) test_core_similarity_score_batch() else print("test_core_similarity_score_batch not found")
if(exists("test_core_annotation_boost", mode = "function")) test_core_annotation_boost() else print("test_core_annotation_boost not found")
print("--- CORE TESTS COMPLETED ---")
cat("\n")

# --- Running Custom Model Tests ---
print("--- STARTING CUSTOM MODEL TESTS ---")
# Setup for custom model tests (defines custom_base_url, custom_model, and loads its own markers_unprocessed globally)
# The setup_custom_deepseek_test function is defined in the restored R chunk below the summary section.
# Ensure that chunk is processed before this one if running interactively, or that it appears earlier in the Rmd file when knitting.
# For now, assuming it will be defined when this is run through knitting.
if(exists("setup_custom_deepseek_test", mode = "function")) setup_custom_deepseek_test() else print("setup_custom_deepseek_test function not found!")

if(exists("test_custom_batch_annotation", mode = "function")) test_custom_batch_annotation() else print("test_custom_batch_annotation not found")
if(exists("test_custom_pipeline", mode = "function")) test_custom_pipeline() else print("test_custom_pipeline not found")
if(exists("test_custom_merge_annotations", mode = "function")) test_custom_merge_annotations() else print("test_custom_merge_annotations not found")
if(exists("test_custom_scoring", mode = "function")) test_custom_scoring() else print("test_custom_scoring not found")
if(exists("test_custom_generate_score_report", mode = "function")) test_custom_generate_score_report() else print("test_custom_generate_score_report not found")
if(exists("test_custom_subcluster", mode = "function")) test_custom_subcluster() else print("test_custom_subcluster not found")
if(exists("test_custom_compare_celltypes", mode = "function")) test_custom_compare_celltypes() else print("test_custom_compare_celltypes not found")
if(exists("test_custom_batch_n_times", mode = "function")) test_custom_batch_n_times() else print("test_custom_batch_n_times not found")
if(exists("test_custom_similarity_score_batch", mode = "function")) test_custom_similarity_score_batch() else print("test_custom_similarity_score_batch not found")
if(exists("test_custom_annotation_boost", mode = "function")) test_custom_annotation_boost() else print("test_custom_annotation_boost not found")
print("--- CUSTOM MODEL TESTS COMPLETED ---")
cat("\n")

# --- Running Other Custom Tests ---
print("--- STARTING OTHER CUSTOM TESTS ---")
if(exists("test_custom_multiple_endpoints", mode = "function")) test_custom_multiple_endpoints() else print("test_custom_multiple_endpoints not found")
if(exists("test_custom_temperature_variations", mode = "function")) test_custom_temperature_variations() else print("test_custom_temperature_variations not found")
print("--- OTHER CUSTOM TESTS COMPLETED ---")
cat("\n")

# --- Custom Model Configuration Summary ---
if(exists("print_custom_model_summary", mode = "function")) print_custom_model_summary() else print("print_custom_model_summary not found")

print("--- ALL TESTS AND SUMMARY COMPLETED ---")
```

```{r setup_custom_deepseek_environment_restored, echo=TRUE}
# This chunk was unintentionally removed and is now restored.
setup_custom_deepseek_test <- function() {
  if (!"package:CASSIA" %in% search()) {
    library(CASSIA)
    print("CASSIA library loaded.")
  }
  print("Setting up custom DeepSeek test environment...")
  markers_unprocessed <<- CASSIA::loadExampleMarkers(processed = FALSE)
  custom_base_url <<- "https://api.deepseek.com"
  custom_model <<- "deepseek-chat"
  CASSIA::setLLMApiKey("sk-f7c54e95a5e040589f41d83553b55861", provider = custom_base_url)
  print("✓ Custom DeepSeek test environment configured:")
  print(paste("  Provider URL set to:", custom_base_url))
  print(paste("  Model set to:", custom_model))
  print("  API key configured for DeepSeek.")
  print("  'markers_unprocessed' data loaded globally.")
  cat("\n")
}

# Call the setup function to prepare for custom model tests
# We will move the actual call later, just defining it here for now.
setup_custom_deepseek_test()
```

```{r test_function_definitions, echo=FALSE}
# --- Test Function Definitions ---
# This chunk will hold all the refactored test functions.

# --- Core Test Functions ---
test_core_pipeline <- function() {
  cat("--- Running Core Test: Pipeline ---\n")
  # Run the CASSIA pipeline in fast mode
  # The original script had markers_unprocessed which would be globally loaded
  fast_results <- runCASSIA_pipeline(
    output_file_name = "TEST2",
    tissue = "large intestine",
    species = "human",
    marker = markers_unprocessed, 
    max_workers = 6,
    score_threshold = 92
  )
  
  # The py_tools$run_cell_analysis_pipeline call was commented out in the user's provided file context for the previous turn
  # If it should be included, it would look like this:
  # print("Attempting direct Python call for run_cell_analysis_pipeline...")
  # fast_results_py <- CASSIA:::py_tools$run_cell_analysis_pipeline(
  #   output_file_name = "TEST1",
  #   tissue = "large intestine",
  #   species = "human",
  #   marker_path = markers_unprocessed,
  #   score_model = "deepseek/deepseek-chat-v3-0324",
  #   score_provider = "openrouter",
  #   max_workers = 6,
  #   score_threshold = 95
  # )
  cat("--- Core Test: Pipeline COMPLETED ---\n\n")
}

test_core_batch_annotation <- function() {
  cat("--- Running Core Test: Batch Annotation ---\n")
  runCASSIA_batch(
    marker = markers_unprocessed,
    output_name = "my_annotation2", 
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    n_genes = 50,
    provider = "openrouter",
    model="google/gemini-2.5-flash-preview"
  )
  cat("--- Core Test: Batch Annotation COMPLETED ---\n\n")
}

test_core_merge_annotations <- function() {
  cat("--- Running Core Test: Merge Annotations ---\n")
  # This test assumes 'my_annotation2_full.csv' is created by test_core_batch_annotation
  # in the current working directory (D:/newgit/CASSIA/CASSIA_R/test_r)
  runCASSIA_merge_annotations( 
    csv_path = "my_annotation2_full.csv", # Using relative path assuming setwd was effective
    provider = "openrouter",
    model = "deepseek/deepseek-chat-v3-0324",
    detail_level = "detailed",
    process_all = TRUE,
    debug = FALSE
  )
  cat("--- Core Test: Merge Annotations COMPLETED ---\n\n")
}

test_core_scoring <- function() {
  cat("--- Running Core Test: Scoring ---\n")
  # Assumes 'my_annotation2_full.csv' exists from test_core_batch_annotation
  quality_scores <- runCASSIA_score_batch(
    input_file = "my_annotation2_full.csv", # Relative path
    output_file = "my_annotation2_full_scored.csv" # Relative path
  )
  cat("--- Core Test: Scoring COMPLETED ---\n\n")
}

test_core_generate_score_report <- function() {
  cat("--- Running Core Test: Generate Score Report ---\n")
  # Assumes 'my_annotation2_full_scored.csv' exists from test_core_scoring
  runCASSIA_generate_score_report(
    csv_path = "my_annotation2_full_scored.csv", # Relative path
    output_name = "my_annotation2_full_scored_report" # Base name for output, .html will be appended by the function if it generates HTML
  )
  cat("--- Core Test: Generate Score Report COMPLETED ---\n\n")
}

test_core_subcluster <- function() {
  cat("--- Running Core Test: Subcluster ---\n")
  # Uses globally loaded marker_sub
  runCASSIA_subclusters(marker = marker_sub, 
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results",
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter"
  )
  cat("--- Core Test: Subcluster COMPLETED ---\n\n")
}

test_core_compare_celltypes <- function() {
  cat("--- Running Core Test: Compare Celltypes ---\n")
  marker_string_for_compare <- "IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1, AC026369.3, IGHV3-23, IGKV4-1, IGKV1-5, IGHA1, IGLV3-1, IGLV2-11, MYL2, MZB1, IGHG3, IGHV3-74, IGHM, ANKRD36BP2, AMPD1, IGKV3-20, IGHA2, DERL3, AC104699.1, LINC02362, AL391056.1, LILRB4, CCL3, BMP6, UBE2QL1, LINC00309, AL133467.1, GPRC5D, FCRL5, DNAAF1, AP002852.1, AC007569.1, CXorf21, RNU1-85P, U62317.4, TXNDC5, LINC02384, CCR10, BFSP2, APOBEC3A, AC106897.1"
  
  compareCelltypes(
    tissue = "large intestine",
    celltypes = c("Plasma Cells","IgA-secreting Plasma Cells","IgG-secreting Plasma Cells","IgM-secreting Plasma Cells"),
    marker = marker_string_for_compare,
    species = "human",
    output_file = "plasama_cell_subtype" # Base name for output
  )
  cat("--- Core Test: Compare Celltypes COMPLETED ---\n\n")
}

test_core_batch_n_times <- function() {
  cat("--- Running Core Test: Batch N Times (Uncertainty Quantification) ---\n")
  # Uses globally loaded markers_unprocessed
  iteration_results <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed,
    output_name = "my_annotation_uncertainty_core", # Specific output name for this test
    model = "meta-llama/llama-4-maverick", # Original model from script
    provider = "openrouter",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    batch_max_workers = 3
  )
  cat("--- Core Test: Batch N Times (Uncertainty Quantification) COMPLETED ---\n\n")
}

test_core_similarity_score_batch <- function() {
  cat("--- Running Core Test: Similarity Score Batch (Uncertainty Quantification) ---\n")
  # This test depends on the output from test_core_batch_n_times.
  # Ensure file_pattern matches the output_name used there (e.g., "my_annotation_uncertainty_core_*_full.csv")
  
  # First call from original script
  similarity_scores_openrouter <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "my_annotation_uncertainty_core_*_full.csv", 
    output_name = "intestine_similarity_core_openrouter", # Changed output name
    max_workers = 6,
    provider = "openrouter",
    model = "google/gemini-2.5-flash-preview"
  )
  
  # Second call from original script (example with OpenAI)
  # Note: The original script had a C:/ path, changed to relative pattern assuming files from test_core_batch_n_times
  similarity_scores_openai <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed,
    file_pattern = "my_annotation_uncertainty_core_*_full.csv", 
    output_name = "intestine_similarity_core_openai", # Changed output name
    max_workers = 6,
    provider = "openai",
    model = "gpt-4o-mini"
  )
  cat("--- Core Test: Similarity Score Batch (Uncertainty Quantification) COMPLETED ---\n\n")
}

test_core_annotation_boost <- function() {
  cat("--- Running Core Test: Annotation Boost ---\n")
  cluster_info_ab <- "Human Large Intestine"
  target_cluster_ab <- "monocyte"

  runCASSIA_annotationboost(
    full_result_path = "my_annotation2_full.csv", 
    marker = markers_unprocessed,
    cluster_name = target_cluster_ab,
    major_cluster_info = cluster_info_ab,
    output_name = "monocyte_report_core",
    num_iterations = 5, 
    model ="google/gemini-2.5-flash-preview",
    provider = "openrouter"
  )
  
  runCASSIA_annotationboost_additional_task(
    full_result_path = "my_annotation2_full.csv",
    marker = markers_unprocessed,
    output_name="monocyte_annotationboost_core",
    cluster_name = target_cluster_ab,
    major_cluster_info = cluster_info_ab,
    num_iterations = 5,
    model = "google/gemini-2.5-flash-preview",
    provider = "openrouter",
    additional_task = "check if this is monocyte"
  )
  cat("--- Core Test: Annotation Boost COMPLETED ---\n\n")
}

# --- Custom Model Test Functions ---
# These functions will use custom_base_url, custom_model, and markers_unprocessed 
# that are set globally by setup_custom_deepseek_test()

test_custom_batch_annotation <- function() {
  cat("--- Running Custom Test: Batch Annotation (DeepSeek) ---\n")
  # setup_custom_deepseek_test() should have set custom_base_url, custom_model, and loaded markers_unprocessed
  # setwd("D:/newgit/CASSIA/CASSIA_R/test_r") # This should be set globally before test calls
  
  runCASSIA_batch(
    marker = markers_unprocessed, # Uses markers_unprocessed from setup_custom_deepseek_test
    output_name = "my_annotation_custom2",
    tissue = "large intestine",
    species = "human",
    max_workers = 6,
    n_genes = 50,
    provider = custom_base_url, # Global variable
    model = custom_model,      # Global variable
    temperature = 0
  )
  cat("--- Custom Test: Batch Annotation (DeepSeek) COMPLETED ---\n\n")
}

test_custom_pipeline <- function() {
  cat("--- Running Custom Test: Pipeline (DeepSeek) ---\n")
  runCASSIA_pipeline(
    output_file_name = "TEST_CUSTOM2",
    tissue = "large intestine", 
    species = "human",
    marker = markers_unprocessed, # Uses markers_unprocessed from setup_custom_deepseek_test
    max_workers = 4,
    annotation_model = custom_model,
    annotation_provider = custom_base_url,
    score_model = custom_model,
    score_provider = custom_base_url,
    annotationboost_model = custom_model,
    annotationboost_provider = custom_base_url,
    merge_model = custom_model, 
    # merge_provider is not an explicit param for runCASSIA_pipeline, 
    # it typically uses annotation_provider if not specified internally for merge steps.
    score_threshold = 75
  )
  cat("--- Custom Test: Pipeline (DeepSeek) COMPLETED ---\n\n")
}

test_custom_merge_annotations <- function() {
  cat("--- Running Custom Test: Merge Annotations (DeepSeek) ---\n")
  # Depends on output from test_custom_batch_annotation
  runCASSIA_merge_annotations(
    csv_path = "my_annotation_custom2_full.csv", 
    provider = custom_base_url,
    model = custom_model,
    detail_level = "detailed",
    process_all = TRUE,
    debug = FALSE
  )
  cat("--- Custom Test: Merge Annotations (DeepSeek) COMPLETED ---\n\n")
}

test_custom_scoring <- function() {
  cat("--- Running Custom Test: Scoring (DeepSeek) ---\n")
  # Depends on output from test_custom_batch_annotation
  quality_scores_custom <- runCASSIA_score_batch(
    input_file = "my_annotation_custom2_full.csv", 
    output_file = "my_annotation_custom2_scored.csv",
    model = custom_model,
    provider = custom_base_url,
    max_workers = 4
  )
  cat("--- Custom Test: Scoring (DeepSeek) COMPLETED ---\n\n")
}

test_custom_generate_score_report <- function() {
  cat("--- Running Custom Test: Generate Score Report (DeepSeek) ---\n")
  # Depends on output from test_custom_scoring
  runCASSIA_generate_score_report(
    csv_path = "my_annotation_custom2_scored.csv",
    output_name = "custom_model2_report" 
  )
  cat("--- Custom Test: Generate Score Report (DeepSeek) COMPLETED ---\n\n")
}

test_custom_subcluster <- function() {
  cat("--- Running Custom Test: Subcluster (DeepSeek) ---\n")
  # Assuming marker_sub is loaded globally (e.g., along with markers_unprocessed for core tests)
  # or setup_custom_deepseek_test could be modified to load it if it needs a specific version.
  runCASSIA_subclusters(
    marker = marker_sub, 
    major_cluster_info = "cd8 t cell",
    output_name = "subclustering_results_custom2",
    model = custom_model,
    provider = custom_base_url,
    temperature = 0
  )
  cat("--- Custom Test: Subcluster (DeepSeek) COMPLETED ---\n\n")
}

test_custom_compare_celltypes <- function() {
  cat("--- Running Custom Test: Compare Celltypes (DeepSeek) ---\n")
  marker_string_custom_compare <- "IGLL5, IGLV6-57, JCHAIN, FAM92B, IGLC3, IGLC2, IGHV3-7, IGKC, TNFRSF17, IGHG1, AC026369.3, IGHV3-23, IGKV4-1, IGKV1-5, IGHA1, IGLV3-1, IGLV2-11, MYL2, MZB1, IGHG3, IGHV3-74, IGHM, ANKRD36BP2, AMPD1, IGKV3-20, IGHA2, DERL3, AC104699.1, LINC02362, AL391056.1, LILRB4, CCL3, BMP6, UBE2QL1, LINC00309, AL133467.1, GPRC5D, FCRL5, DNAAF1, AP002852.1, AC007569.1, CXorf21, RNU1-85P, U62317.4, TXNDC5, LINC02384, CCR10, BFSP2, APOBEC3A, AC106897.1"
  # The original script had custom_model_list <- c(custom_model, "backup-model-name")
  # compareCelltypes takes a single model and provider, or a list of full model specs for model_list
  # For simplicity here, using the primary custom_model and custom_base_url.
  # If multiple models from different providers needed, model_list would be structured differently.
  compareCelltypes(
    tissue = "large intestine",
    celltypes = c("Plasma Cells", "IgA-secreting Plasma Cells", "IgG-secreting Plasma Cells", "IgM-secreting Plasma Cells"),
    marker = marker_string_custom_compare,
    species = "human",
    model = custom_model, # Using the single custom_model here
    provider = custom_base_url,
    output_file = "plasma_cell_subtype_custom"
  )
  cat("--- Custom Test: Compare Celltypes (DeepSeek) COMPLETED ---\n\n")
}

test_custom_batch_n_times <- function() {
  cat("--- Running Custom Test: Batch N Times (DeepSeek Uncertainty) ---\n")
  iteration_results_custom <- runCASSIA_batch_n_times(
    n = 3,
    marker = markers_unprocessed, # Uses markers_unprocessed from setup_custom_deepseek_test
    output_name = "my_annotation_custom_uncertainty2",
    model = custom_model,
    provider = custom_base_url,
    tissue = "large intestine",
    species = "human",
    max_workers = 4,
    batch_max_workers = 2,
    temperature = 0
  )
  cat("--- Custom Test: Batch N Times (DeepSeek Uncertainty) COMPLETED ---\n\n")
}

test_custom_similarity_score_batch <- function() {
  cat("--- Running Custom Test: Similarity Score Batch (DeepSeek Uncertainty) ---\n")
  # Depends on output from test_custom_batch_n_times
  similarity_scores_custom <- runCASSIA_similarity_score_batch(
    marker = markers_unprocessed, # Uses markers_unprocessed from setup_custom_deepseek_test
    file_pattern = "my_annotation_custom_uncertainty2_*_full.csv",
    output_name = "intestine_similarity_custom2",
    max_workers = 4,
    provider = custom_base_url,
    model = custom_model
  )
  cat("--- Custom Test: Similarity Score Batch (DeepSeek Uncertainty) COMPLETED ---\n\n")
}

test_custom_annotation_boost <- function() {
  cat("--- Running Custom Test: Annotation Boost (DeepSeek) ---\n")
  cluster_info_custom_ab <- "Human Large Intestine"
  target_cluster_custom_ab <- "monocyte"
  
  runCASSIA_annotationboost(
    full_result_path = "my_annotation_custom2_full.csv", 
    marker = markers_unprocessed, 
    cluster_name = target_cluster_custom_ab,
    major_cluster_info = cluster_info_custom_ab,
    output_name = "monocyte_report_custom",
    num_iterations = 3,
    model = custom_model,
    provider = custom_base_url,
    temperature = 0
  )
  
  runCASSIA_annotationboost_additional_task(
    full_result_path = "my_annotation_custom2_full.csv", 
    marker = markers_unprocessed, 
    output_name = "monocyte_boost_custom",
    cluster_name = target_cluster_custom_ab,
    major_cluster_info = cluster_info_custom_ab,
    num_iterations = 3,
    model = custom_model,
    provider = custom_base_url,
    additional_task = "check if this is a monocyte and assess confidence",
    temperature = 0
  )
  cat("--- Custom Test: Annotation Boost (DeepSeek) COMPLETED ---\n\n")
}


# --- Other Custom Tests ---
test_custom_multiple_endpoints <- function() {
  cat("--- Running Custom Test: Multiple Endpoints ---\n")
  # This test uses markers_unprocessed which should be globally available from setup_custom_deepseek_test()
  custom_endpoints <- list(
    primary = list(base_url = "http://localhost:11434", model = "llama3.2:latest"),
    secondary = list(base_url = "http://localhost:8080", model = "mistral:latest"),
    tertiary = list(base_url = "https://api.your-custom-service.com/v1", model = "custom-model-v2")
  )
  
  print("Testing with primary custom endpoint...")
  tryCatch({
    runCASSIA_batch(
      marker = markers_unprocessed[1:3, ],  # Small subset for testing
      output_name = "test_primary_custom",
      tissue = "large intestine",
      species = "human",
      max_workers = 2,
      n_genes = 20,
      provider = custom_endpoints$primary$base_url,
      model = custom_endpoints$primary$model,
      temperature = 0.1
    )
    print("✓ Primary custom endpoint test completed")
  }, error = function(e) {
    print(paste("✗ Primary custom endpoint failed:", e$message))
  })
  cat("--- Custom Test: Multiple Endpoints COMPLETED ---\n\n")
}

test_custom_temperature_variations <- function() {
  cat("--- Running Custom Test: Temperature Variations (DeepSeek) ---\n")
  # This test uses custom_model and custom_base_url globally set by setup_custom_deepseek_test()
  temperature_tests <- c(0, 0.3, 0.7, 1.0)
  
  for (temp in temperature_tests) {
    tryCatch({
      print(paste("Testing temperature:", temp))
      
      runCASSIA(
        model = custom_model, 
        temperature = temp,
        marker_list = c("CD14", "CD68", "CSF1R", "CX3CR1", "CD163"),
        tissue = "large intestine",
        species = "human",
        additional_info = paste("Temperature test:", temp),
        provider = custom_base_url 
      )
      
      print(paste("✓ Temperature", temp, "test completed"))
      
    }, error = function(e) {
      print(paste("✗ Temperature", temp, "test failed:", e$message))
    })
  }
      cat("--- Custom Test: Temperature Variations (DeepSeek) COMPLETED ---\n\n")
  }

# Debug version of runCASSIA_batch that captures conversation history
runCASSIA_batch_debug <- function(marker, output_name = "cell_type_analysis_results.json", 
                          model = "google/gemini-2.5-flash-preview", temperature = 0, tissue = "lung", 
                          species = "human", additional_info = NULL, 
                          celltype_column = NULL, gene_column_name = NULL, 
                          max_workers = 10, provider = "openrouter", n_genes = 50,
                          max_retries = 1, debug_cluster = "monocyte") {
  
  # Convert R dataframe to Python if marker is a dataframe
  if (is.data.frame(marker)) {
    # Determine the cluster column to check
    cluster_col <- if (!is.null(celltype_column)) celltype_column else "cluster"
    
    # If the cluster column exists and is a factor, convert it to character
    if (cluster_col %in% names(marker) && is.factor(marker[[cluster_col]])) {
      marker[[cluster_col]] <- as.character(marker[[cluster_col]])
    }
    
    # Print debug info about the debug cluster
    if (debug_cluster %in% marker[[cluster_col]]) {
      debug_data <- marker[marker[[cluster_col]] == debug_cluster, ]
      cat("=== DEBUG INFO FOR", debug_cluster, "CLUSTER ===\n")
      cat("Number of rows for", debug_cluster, ":", nrow(debug_data), "\n")
      cat("Cluster column type:", class(marker[[cluster_col]]), "\n")
      cat("Sample marker data for", debug_cluster, ":\n")
      print(head(debug_data))
      
      # Check the marker genes for this cluster
      gene_col <- if (!is.null(gene_column_name)) gene_column_name else names(marker)[2]
      if (nrow(debug_data) > 0) {
        sample_genes <- debug_data[[gene_col]][1:min(10, nrow(debug_data))]
        cat("Sample genes:", paste(sample_genes, collapse = ", "), "\n")
      }
      cat("=====================================\n\n")
    }
    
    pd <- reticulate::import("pandas")
    marker <- reticulate::r_to_py(marker, convert = TRUE)
  }
  
  # Call the Python function and capture the full result
  tryCatch({
    result <- py_tools$runCASSIA_batch(
      marker = marker,
      output_name = output_name,
      model = model,
      temperature = temperature,
      tissue = tissue,
      species = species,
      additional_info = additional_info,
      celltype_column = celltype_column,
      gene_column_name = gene_column_name,
      max_workers = as.integer(max_workers),
      provider = provider,
      n_genes = as.integer(n_genes),
      max_retries = as.integer(max_retries)
    )
    
    # The Python function returns a dictionary of results
    # Let's extract conversation history for the debug cluster
    if (debug_cluster %in% names(result)) {
      cat("\n=== CONVERSATION HISTORY FOR", debug_cluster, "===\n")
      debug_result <- result[[debug_cluster]]
      if ("conversation_history" %in% names(debug_result)) {
        conv_history <- debug_result[["conversation_history"]]
        for (i in seq_along(conv_history)) {
          entry <- conv_history[[i]]
          cat("Agent:", entry[[1]], "\n")
          cat("Message:", substr(entry[[2]], 1, 1000), "...\n")
          cat("---\n")
        }
      }
      cat("=== END CONVERSATION HISTORY ===\n\n")
    }
    
    return(result)
    
  }, error = function(e) {
    cat("=== ERROR DETAILS ===\n")
    cat("Error message:", e$message, "\n")
    cat("Python traceback:", reticulate::py_last_error(), "\n")
    cat("==================\n")
    stop(e)
  })
}

```
# --- Summary Functions ---
print_custom_model_summary <- function() {
  cat("--- Printing Custom Model Summary ---\n")
  # This function uses custom_base_url and custom_model globally set by setup_custom_deepseek_test()
  print("🎯 Custom Model Testing Summary:")
  print("==================================")
  print(paste("Base URL:", custom_base_url))
  print(paste("Model:", custom_model))
  print("")
  print("Tested Functions:")
  print("✓ runCASSIA_batch")
  print("✓ runCASSIA_pipeline") 
  print("✓ runCASSIA_merge_annotations")
  print("✓ runCASSIA_score_batch")
  print("✓ runCASSIA_subclusters")
  print("✓ compareCelltypes")
  print("✓ runCASSIA_batch_n_times")
  print("✓ runCASSIA_similarity_score_batch")
  print("✓ runCASSIA_annotationboost")
  print("✓ runCASSIA_annotationboost_additional_task")
  print("")
  print("📁 Output files generated with '_custom' suffix")
  print("🔧 All functions tested with custom HTTP endpoint")
  cat("--- Custom Model Summary Printed ---\n\n")
}

# --- End of Test Function Definitions ---