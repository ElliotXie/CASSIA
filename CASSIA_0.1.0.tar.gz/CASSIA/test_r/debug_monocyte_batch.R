# Debug script for runCASSIA_batch monocyte cluster issue
# This script isolates and debugs the specific JSON parsing problem with monocyte cluster

# ===== SETUP =====
cat("=== SETTING UP DEBUG ENVIRONMENT ===\n")

# Load required libraries
library(CASSIA)
library(dplyr)
library(reticulate)

# Set working directory
setwd("D:/newgit/CASSIA/CASSIA_R/test_r")
cat("Working directory:", getwd(), "\n")

# Ensure py_tools is available globally
if (!exists("py_tools", envir = .GlobalEnv)) {
  py_tools <<- CASSIA:::py_tools
  if (is.null(py_tools)) {
    stop("Failed to access py_tools. Please ensure CASSIA is properly installed.")
  }
  cat("py_tools loaded successfully.\n")
}

# ===== DATA PREPARATION =====
cat("\n=== LOADING AND PREPARING DATA ===\n")

# Load marker data
markers_unprocessed <- CASSIA::loadExampleMarkers(processed = FALSE)

# Ensure cluster column is character (crucial for avoiding factor->integer conversion)
if (is.factor(markers_unprocessed$cluster)) {
  markers_unprocessed$cluster <- as.character(markers_unprocessed$cluster)
  cat("Converted cluster column from factor to character.\n")
}

cat("Data loaded. Shape:", nrow(markers_unprocessed), "rows,", ncol(markers_unprocessed), "columns\n")
cat("Unique clusters:", paste(unique(markers_unprocessed$cluster), collapse = ", "), "\n")

# Check monocyte cluster specifically
monocyte_rows <- sum(markers_unprocessed$cluster == "monocyte")
cat("Monocyte cluster rows:", monocyte_rows, "\n")

# ===== EXTRACT MONOCYTE DATA =====
cat("\n=== EXTRACTING MONOCYTE CLUSTER DATA ===\n")

# Get monocyte cluster data
monocyte_data <- markers_unprocessed[markers_unprocessed$cluster == "monocyte", ]
cat("Monocyte data extracted:", nrow(monocyte_data), "rows\n")

# Get top marker genes for monocyte (mimicking what runCASSIA_batch does)
n_genes <- 50
cat("Getting top", n_genes, "genes for monocyte cluster...\n")

# Use the get_top_markers function to process the data
monocyte_top <- py_tools$get_top_markers(
  df = reticulate::r_to_py(monocyte_data, convert = TRUE),
  n_genes = as.integer(n_genes),
  ranking_method = "avg_log2FC"
)

# Convert back to R to inspect
monocyte_top_r <- reticulate::py_to_r(monocyte_top)
cat("Top genes processed. Shape:", nrow(monocyte_top_r), "x", ncol(monocyte_top_r), "\n")

# Get the marker list for monocyte
gene_col <- names(monocyte_top_r)[2]  # Second column should be genes
marker_list <- monocyte_top_r[[gene_col]]

cat("Gene column name:", gene_col, "\n")
cat("Number of genes in marker list:", length(marker_list), "\n")
cat("First 10 genes:", paste(marker_list[1:10], collapse = ", "), "\n")

# Check for any problematic characters in the marker list
unusual_genes <- marker_list[grepl("[^A-Za-z0-9._-]", marker_list)]
if (length(unusual_genes) > 0) {
  cat("WARNING: Found genes with unusual characters:\n")
  for (gene in unusual_genes) {
    cat("  '", gene, "' (length:", nchar(gene), ")\n", sep = "")
  }
}

# ===== DIRECT INDIVIDUAL ANALYSIS =====
cat("\n=== CALLING INDIVIDUAL runCASSIA FOR MONOCYTE ===\n")

# Call the individual runCASSIA function directly (not the batch version)
# This should give us the full conversation history
tryCatch({
  cat("Calling py_tools$runCASSIA with parameters:\n")
  cat("- Model: google/gemini-2.5-flash\n")
  cat("- Provider: openrouter\n")
  cat("- Temperature: 0\n")
  cat("- Tissue: large intestine\n")
  cat("- Species: human\n")
  cat("- Marker list length:", length(marker_list), "\n\n")
  
  # Convert marker list to Python list
  marker_list_py <- reticulate::r_to_py(marker_list, convert = TRUE)
  
  result <- py_tools$runCASSIA(
    model = "google/gemini-2.5-flash",
    temperature = 0,
    marker_list = marker_list_py,
    tissue = "large intestine",
    species = "human",
    additional_info = NULL,
    provider = "openrouter"
  )
  
  cat("=== SUCCESS! Analysis completed for monocyte ===\n")
  
  # Extract structured output and conversation history
  structured_output <- result[[1]]
  conversation_history <- result[[2]]
  
  cat("\n=== ANALYSIS RESULT ===\n")
  cat("Main cell type:", structured_output[["main_cell_type"]], "\n")
  cat("Sub cell types:", paste(structured_output[["sub_cell_types"]], collapse = ", "), "\n")
  cat("Mixed types:", paste(structured_output[["possible_mixed_cell_types"]], collapse = ", "), "\n")
  
  cat("\n=== FULL CONVERSATION HISTORY ===\n")
  for (i in seq_along(conversation_history)) {
    entry <- conversation_history[[i]]
    agent <- entry[[1]]
    message <- entry[[2]]
    
    cat("\n--- Conversation Entry", i, "---\n")
    cat("Agent:", agent, "\n")
    cat("Message length:", nchar(message), "characters\n")
    
    if (agent == "user") {
      cat("USER PROMPT:\n")
      cat(message, "\n")
    } else {
      cat("LLM RESPONSE:\n")
      if (nchar(message) < 3000) {
        cat(message, "\n")
      } else {
        cat("First 1500 characters:\n")
        cat(substr(message, 1, 1500), "\n")
        cat("\n... [TRUNCATED] ...\n\n")
        cat("Last 1000 characters:\n")
        cat(substr(message, nchar(message)-999, nchar(message)), "\n")
      }
      
      # Try to extract and parse JSON from the response
      cat("\n--- JSON ANALYSIS ---\n")
      json_match <- regexpr("\\{.*\\}", message, perl = TRUE)
      if (json_match > 0) {
        json_str <- regmatches(message, json_match)
        cat("Found JSON (length:", nchar(json_str), "):\n")
        cat(json_str, "\n")
        
        # Try to parse it
        tryCatch({
          parsed <- jsonlite::fromJSON(json_str)
          cat("JSON PARSING: SUCCESS\n")
        }, error = function(e) {
          cat("JSON PARSING: FAILED\n")
          cat("Error:", e$message, "\n")
          
          # Show character-by-character analysis around the error
          if (grepl("column \\d+", e$message)) {
            error_pos <- as.numeric(gsub(".*column (\\d+).*", "\\1", e$message))
            start_pos <- max(1, error_pos - 20)
            end_pos <- min(nchar(json_str), error_pos + 20)
            context <- substr(json_str, start_pos, end_pos)
            cat("Context around error position", error_pos, ":\n")
            cat("'", context, "'\n")
            
            # Show each character with its ASCII code
            cat("Character-by-character analysis:\n")
            for (j in start_pos:end_pos) {
              char <- substr(json_str, j, j)
              ascii <- utf8ToInt(char)
              cat("Pos", j, ": '", char, "' (ASCII:", ascii, ")\n")
            }
          }
        })
      } else {
        cat("No JSON found in response\n")
      }
    }
    cat("========================\n")
  }
  
}, error = function(e) {
  cat("\n=== ERROR IN INDIVIDUAL ANALYSIS ===\n")
  cat("Error message:", e$message, "\n")
  cat("Python traceback:\n")
  cat(reticulate::py_last_error(), "\n")
  cat("====================================\n")
})

cat("\n=== DEBUG ANALYSIS COMPLETED ===\n") 