from tools_function import *

output_file_name = "test_batch"
score_file_name = output_file_name + "_scored.csv"
max_workers = 4
tissue = "lung"
species = "human"
annottaion_model = "gpt-4o"
annottaion_provider = "openai"
marker = "C:/Users/ellio/OneDrive - UW-Madison/cellgpt_final_folder/paper_results/immune_projecttils/marker_kidney_modify.csv"
score_model = "anthropic/claude-3.5-sonnet"
score_provider = "openrouter"
report_name = output_file_name + "_report"
lowscore_report_name = output_file_name + "_lowscore_report"
score_threshold = 75




def run_cell_analysis_pipeline(
    output_file_name: str,
    tissue: str,
    species: str,
    marker_path: str,
    max_workers: int = 4,
    annotation_model: str = "gpt-4",
    annotation_provider: str = "openai",
    score_model: str = "anthropic/claude-3.5-sonnet",
    score_provider: str = "openrouter",
    score_threshold: float = 75,
    additional_info: str = "None"
):
    """
    Run the complete cell analysis pipeline including annotation, scoring, and report generation.
    
    Args:
        output_file_name (str): Base name for output files
        tissue (str): Tissue type being analyzed
        species (str): Species being analyzed
        marker_path (str): Path to marker file
        max_workers (int): Maximum number of concurrent workers
        annotation_model (str): Model to use for annotation
        annotation_provider (str): Provider for annotation
        score_model (str): Model to use for scoring
        score_provider (str): Provider for scoring
        score_threshold (float): Threshold for identifying low-scoring clusters
        additional_info (str): Additional information for analysis
    """
    # Define derived file names
    score_file_name = output_file_name + "_scored.csv"
    report_name = output_file_name + "_report"
    lowscore_report_name = output_file_name + "_lowscore_report"

    print("\n=== Starting cell type analysis ===")
    # Run initial cell type analysis
    run_cell_type_analysis_batchrun(
        marker=marker_path,
        output_name=output_file_name,
        model=annotation_model,
        tissue=tissue,
        species=species,
        additional_info=additional_info,
        provider=annotation_provider
    )
    print("✓ Cell type analysis completed")

    print("\n=== Starting scoring process ===")
    # Run scoring
    run_scoring_with_progress(
        input_file=output_file_name + "_full.csv",
        output_file=score_file_name,
        max_workers=max_workers,
        model=score_model,
        provider=score_provider
    )
    print("✓ Scoring process completed")

    print("\n=== Generating main reports ===")
    # Process reports
    process_all_reports(
        csv_path=score_file_name,
        index_name=report_name
    )
    print("✓ Main reports generated")

    print("\n=== Analyzing low-scoring clusters ===")
    # Handle low-scoring clusters
    df = pd.read_csv(score_file_name)
    low_score_clusters = df[df['Score'] < score_threshold]['True Cell Type'].tolist()

    print(f"Found {len(low_score_clusters)} clusters with scores below {score_threshold}:")
    print(low_score_clusters)

    # Process each low-scoring cluster
    for i, cluster in enumerate(low_score_clusters, 1):
        print(f"\nProcessing low-score cluster {i}/{len(low_score_clusters)}: {cluster}")
        generate_cell_type_analysis_report_wrapper(
            full_result_path=output_file_name + "_full.csv",
            marker=marker_path,
            cluster_name=cluster,
            major_cluster_info=f"{species} {tissue}",
            output_name=f"{cluster}_{lowscore_report_name}",
            num_iterations=5,
            model=score_model,
            provider=score_provider
        )
        print(f"✓ Completed analysis for cluster: {cluster}")

    print("\n=== Pipeline completed successfully ===")


run_cell_analysis_pipeline(
    output_file_name="test_batch",
    tissue="kidney",
    species="human",
    marker_path="C:/Users/ellio/OneDrive - UW-Madison/cellgpt_final_folder/paper_results/immune_projecttils/marker_kidney_modify.csv",
    max_workers=4,
    annotation_model="gpt-4o",
    annotation_provider="openai",
    score_model="anthropic/claude-3.5-sonnet",
    score_provider="openrouter",
    score_threshold=95,
    additional_info="None"
)