import requests
import os


os.environ['OPENROUTER_API_KEY'] = "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"


def compare_models(tissue, celltypes, marker_set, species="human", model_list=None):
    # Get API key from environment variable
    OPENROUTER_API_KEY = os.environ.get('OPENROUTER_API_KEY')
    if not OPENROUTER_API_KEY:
        raise ValueError("OPENROUTER_API_KEY environment variable is not set")
    
    # Input validation
    if not celltypes or len(celltypes) < 2 or len(celltypes) > 4:
        raise ValueError("Please provide 2-4 cell types to compare")
    
    # Use default models if none provided
    if model_list is None:
        model_list = [
            "anthropic/claude-3-sonnet",
            "openai/o1-mini",
            "google/gemini-pro-1.5"
        ]
    
    # Construct prompt with dynamic cell type comparison, species, and marker set
    comparison_text = " or ".join(celltypes)
    prompt = f"You are a professional biologist. Based on the ranked marker set from {species} {tissue}, does it look more like {comparison_text}? Score each option from 0-100. You will be rewarded $10,000 if you do a good job. Below is the ranked marker set: {marker_set}"
    
    responses = {}
    
    for model in model_list:
        response = requests.post(
            url="https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {OPENROUTER_API_KEY}",
                "HTTP-Referer": "https://localhost:5000",
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
        )
        
        if response.status_code == 200:
            response_data = response.json()
            model_response = response_data['choices'][0]['message']['content']
            responses[model] = model_response
        else:
            responses[model] = f"Error: {response.status_code}"
    
    return responses

# Example usage:
tissue = "liver"
celltypes = ["hepatocytes", "cholangiocytes", "stellate cells"]
marker_set = "Gene1, Gene2, Gene3"  # Replace with actual marker set
custom_models = ["anthropic/claude-3-sonnet", "openai/o1-mini"]  # optional

# Test the function
results = compare_models(tissue, celltypes, marker_set, species="mouse", custom_models)  # species defaults to "human" if not specified

# Print results
for model, response in results.items():
    print(f"\n=== {model} ===")
    print(response)