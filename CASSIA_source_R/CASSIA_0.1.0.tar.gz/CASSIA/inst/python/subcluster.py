import anthropic
import re
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
import os

def openrouter_agent(user_message, model="anthropic/claude-3-5-sonnet", temperature=0):
    """
    Send a message to OpenRouter API and get the response.
    
    Args:
        user_message (str): The message to send to the model
        model (str): OpenRouter model identifier (default: "anthropic/claude-3-sonnet")
        temperature (float): Temperature parameter for response generation (default: 0)
        
    Returns:
        str: Model's response text or empty string if request fails
    """
    try:
        response = requests.post(
            url="https://openrouter.ai/api/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {os.environ.get('OPENROUTER_API_KEY')}",
                "HTTP-Referer": "https://localhost:5000",  # Required for OpenRouter
                "Content-Type": "application/json"
            },
            json={
                "model": model,
                "temperature": temperature,
                "max_tokens": 7000,
                "messages": [
                    {
                        "role": "user",
                        "content": user_message
                    }
                ]
            }
        )
        
        # Check if request was successful
        if response.status_code == 200:
            response_data = response.json()
            return response_data['choices'][0]['message']['content']
        else:
            print(f"Error: OpenRouter API returned status code {response.status_code}")
            print(f"Response: {response.text}")
            return ''
            
    except Exception as e:
        print(f"Error making OpenRouter API request: {str(e)}")
        return ''
    



def subcluster_agent_annotate_subcluster(user_message,model="claude-3-5-sonnet-20241022",temperature=0,provider="anthropic"):
    if provider == "anthropic":
        client = anthropic.Anthropic()

        message = client.messages.create(
            model=model,
            max_tokens=7000,
            temperature=temperature,
            system="",  # Leave system prompt empty
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": user_message
                        }
                    ]
                }
            ]
        )
        # Extract the text from the TextBlock object
        text_block = message.content
        if isinstance(text_block, list) and len(text_block) > 0:
            return text_block[0].text  # Directly access the 'text' attribute
    else:  # OpenRouter
        return openrouter_agent(user_message, model=model, temperature=temperature)
    return ''



def construct_prompt_from_csv_subcluster(csv_file_path, major_cluster_info):
    # Read the CSV file
    df = pd.read_csv(csv_file_path)

    # Initialize the prompt with the major cluster information
    prompt = f"""

You are an expert biologist specializing in cell type annotation, with deep expertise in immunology, cancer biology, and developmental biology.You will be given sets of highly expressed markers ranked by significance for some subclusters from the {major_cluster_info} cluster, identify what is the most likely top2 cell type each marker set implies.

Take a deep breath and work step by step. You'd better do a really good job or 1000 grandma are going to be in danger.
You will be tipped $10,000 if you do a good job.

For each output, provide:
1.Key marker:
2.Explanation:
3.Most likely top2 cell types:

Remember these subclusters are from a {major_cluster_info} big cluster. You must include all clusters mentioned in the analysis.
"""

    # Iterate over each row in the DataFrame
    for index, row in df.iterrows():
        cluster_name = row.iloc[0]  # Use iloc for positional indexing
        markers = row.iloc[1]       # Use iloc for positional indexing
        prompt += f"{index + 1}.{markers}\n"

    return prompt



def annotate_subclusters(csv_file_path, major_cluster_info,model="claude-3-5-sonnet-20241022",temperature=0,provider="anthropic"):
    prompt = construct_prompt_from_csv_subcluster(csv_file_path, major_cluster_info)
    output_text = subcluster_agent_annotate_subcluster(prompt,model=model,temperature=temperature,provider=provider)
    return output_text



def extract_subcluster_results_with_llm_multiple_output(analysis_text):
    # Define the prompt to instruct the LLM
    prompt = f"""
You are an expert in analyzing celltype annotation for subclusters. Extract the results perfectly and accurately from the following analysis and format them as: results1(celltype1, celltype2), results2(celltype1, celltype2), etc.

You should include all clusters mentioned in the analysis or 1000 grandma will be in danger.

{analysis_text}
"""

    # Use the subcluster_agent_annotate function to get the extraction
    return subcluster_agent_annotate_subcluster(prompt)




def extract_subcluster_results_with_llm(analysis_text):
    # Define the prompt to instruct the LLM
    prompt = f"""
You are an expert in analyzing celltype annotation for subclusters. Extract the results perfectly and accurately from the following analysis and format them as: results1(celltype1, celltype2,reason), results2(celltype1, celltype2,reason), etc.

You should include all clusters mentioned in the analysis or 1000 grandma will be in danger.

{analysis_text}
"""

    # Use the subcluster_agent_annotate function to get the extraction
    return subcluster_agent_annotate_subcluster(prompt)



def write_results_to_csv(results, output_path='subcluster_results.csv'):
    """
    Extract cell type results from LLM output and write to CSV file
    
    Args:
        results (str): String containing the LLM analysis results
        output_path (str): Path where CSV file should be saved
        
    Returns:
        pandas.DataFrame: DataFrame containing the extracted results
    """
    # Updated regex pattern to capture the reason
    pattern = r"results(\d+)\(([^,]+),\s*([^,]+),\s*([^)]+)\)"
    matches = re.findall(pattern, results)

    # Convert matches to a DataFrame with the reason column
    df = pd.DataFrame(matches, columns=['Result ID', 'main_cell_type', 'sub_cell_type', 'reason'])
    
    # Write the DataFrame to a CSV file
    df.to_csv(output_path, index=False)
    
    print(f"Results have been written to {output_path}")
    return None



def process_subclusters(csv_file_path, major_cluster_info, output_path, 
                       model="claude-3-5-sonnet-20241022", temperature=0, provider="anthropic"):
    """
    Process subclusters from a CSV file and generate annotated results
    
    Args:
        csv_file_path (str): Path to input CSV file containing marker data
        major_cluster_info (str): Description of the major cluster type
        output_path (str): Path where results CSV should be saved
        model (str): Model name for Claude API
        temperature (float): Temperature parameter for API calls
        
    Returns:
        tuple: (original_analysis, extracted_results, results_dataframe)
    """

    prompt = construct_prompt_from_csv_subcluster(csv_file_path, major_cluster_info)
    output_text = subcluster_agent_annotate_subcluster(prompt,model=model,temperature=temperature,provider=provider)
    print(output_text)
    results = extract_subcluster_results_with_llm(output_text)
    print(results)
    write_results_to_csv(results, output_path)
    
    return None



def run_analysis_multiple_times_subcluster(n, csv_file_path, major_cluster_info, base_output_name, 
                                         model="claude-3-5-sonnet-20241022", temperature=0, 
                                         provider="anthropic", max_workers=5):
    def run_single_analysis(i):
        # Run the annotation process
        output_text = annotate_subclusters(csv_file_path, major_cluster_info, 
                                         model=model, temperature=temperature, provider=provider)
        
        # Extract results
        results = extract_subcluster_results_with_llm_multiple_output(output_text)
        
        # Use regex to extract the results
        pattern = r"results(\d+)\(([^,]+),\s*([^)]+)\)"
        matches = re.findall(pattern, results)
        
        # Convert matches to a DataFrame
        df = pd.DataFrame(matches, columns=['True Cell Type', 'main_cell_type', 'sub_cell_type'])

        # Swap the first column with the first column in the marker file
        marker_df = pd.read_csv(csv_file_path)
        df['True Cell Type'], marker_df.iloc[:, 0] = marker_df.iloc[:, 0], df['True Cell Type']

        # Write the DataFrame to a CSV file with an index
        indexed_csv_file_path = f'{base_output_name}_{i+1}.csv'
        df.to_csv(indexed_csv_file_path, index=False)
        
        return indexed_csv_file_path

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(run_single_analysis, i): i for i in range(n)}
        
        for future in as_completed(futures):
            i = futures[future]
            try:
                result_file = future.result()
                print(f"Results for iteration {i+1} have been written to {result_file}")
            except Exception as exc:
                print(f"Iteration {i+1} generated an exception: {exc}")


