from pathlib import Path
import re


def convert_markdown_to_html(text):
    """
    Converts markdown-like syntax to HTML using regex patterns.
    """
    # Replace first h1 title with CASSIA Analysis Report
    text = re.sub(r'^# .*?$', '# CASSIA Analysis Report', text, count=1, flags=re.MULTILINE)
    
    # Convert headers
    text = re.sub(r'^# (.*?)$', r'<h1><span class="highlight">\1</span></h1>', text, flags=re.MULTILINE)
    text = re.sub(r'^## (.*?)$', r'<h2><span class="highlight">\1</span></h2>', text, flags=re.MULTILINE)
    text = re.sub(
        r'^### Phase (\d+): (.*?)$',
        r'<h3 class="phase-header phase-\1"><span class="phase-number">Phase \1</span><span class="phase-title">\2</span></h3>',
        text,
        flags=re.MULTILINE
    )
    text = re.sub(r'^#### (.*?)$', r'<h4><span class="highlight">\1</span></h4>', text, flags=re.MULTILINE)
    
    # Convert lists with custom bullets
    text = re.sub(r'^\- (.*?)$', r'<li class="custom-bullet">\1</li>', text, flags=re.MULTILINE)
    text = re.sub(r'(<li.*?</li>\n)+', r'<ul class="custom-list">\g<0></ul>', text, flags=re.DOTALL)
    
    # Convert numbered lists
    text = re.sub(r'^\d+\. (.*?)$', r'<li>\1</li>', text, flags=re.MULTILINE)
    text = re.sub(r'(<li>.*?</li>\n)+', r'<ol class="numbered-list">\g<0></ol>', text, flags=re.DOTALL)
    
    # Convert paragraphs
    text = re.sub(r'\n\n(.*?)\n\n', r'\n<p class="fade-in">\1</p>\n', text, flags=re.DOTALL)
    
    # Convert bold text
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong class="highlight-text">\1</strong>', text)
    
    # Convert italic text
    text = re.sub(r'\*(.*?)\*', r'<em class="emphasis">\1</em>', text)
    
    return text

def render_report_to_html(report_content, output_path):
    """
    Renders a markdown-like report to a styled HTML file with high-tech aesthetics.
    """
    # Generate CSS color pairs for 15 phases
    color_pairs = []
    for i in range(15):
        hue = (i * 137.5) % 360  # Golden angle approximation for better color distribution
        color_pairs.append(
            f"--phase-{i+1}-start: hsl({hue}, 70%, 45%);\n"
            f"--phase-{i+1}-end: hsl({(hue + 20) % 360}, 80%, 60%);"
        )
    
    css = """
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=JetBrains+Mono&display=swap');
        
        :root {
            """ + "\n            ".join(color_pairs) + """
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.7;
            max-width: 1000px;
            margin: 0 auto;
            padding: 20px;
            background-color: var(--bg);
            color: var(--text);
        }

        .container {
            background-color: var(--card-bg);
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
                        0 2px 4px -1px rgba(0, 0, 0, 0.06);
            animation: slideIn 0.6s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1, h2, h3, h4 {
            font-weight: 600;
            line-height: 1.3;
            margin-top: 1.5em;
            margin-bottom: 0.8em;
        }

        h1 {
            font-size: 2.5em;
            color: #1e40af;
            margin-top: 0;
            text-align: center;
            padding: 0.5em 0;
            animation: fadeInDown 0.8s ease-out;
            font-weight: 800;
        }

        h1 .highlight {
            background: linear-gradient(120deg, #1e40af, #3b82f6);
            color: transparent;
            -webkit-background-clip: text;
            background-clip: text;
            display: inline-block;
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h2 {
            font-size: 1.8em;
            color: var(--secondary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.3em;
        }

        h3 {
            font-size: 1.4em;
            color: var(--accent);
        }

        h4 {
            font-size: 1.2em;
            color: var(--primary);
        }

        .highlight {
            position: relative;
            z-index: 1;
        }

        .custom-list {
            list-style: none;
            padding-left: 0;
        }

        .custom-bullet {
            position: relative;
            padding-left: 1.5em;
            margin: 0.5em 0;
        }

        .custom-bullet::before {
            content: '▹';
            position: absolute;
            left: 0;
            color: var(--primary);
        }

        .numbered-list {
            counter-reset: item;
            list-style: none;
            padding-left: 0;
        }

        .numbered-list li {
            counter-increment: item;
            margin: 0.5em 0;
            padding-left: 2em;
            position: relative;
        }

        .numbered-list li::before {
            content: counter(item);
            position: absolute;
            left: 0;
            width: 1.5em;
            height: 1.5em;
            background-color: var(--primary);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8em;
        }

        p {
            margin: 1em 0;
            opacity: 0;
            animation: fadeIn 0.5s ease-out forwards;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }

        .highlight-text {
            background: linear-gradient(120deg, rgba(45, 212, 191, 0.2), rgba(6, 182, 212, 0.2));
            padding: 0.1em 0.3em;
            border-radius: 4px;
            font-weight: 600;
        }

        .emphasis {
            color: var(--accent);
            font-style: italic;
        }

        code {
            font-family: 'JetBrains Mono', monospace;
            background-color: #f1f5f9;
            padding: 0.2em 0.4em;
            border-radius: 4px;
            font-size: 0.9em;
        }

        blockquote {
            border-left: 4px solid var(--primary);
            margin: 1.5em 0;
            padding: 1em;
            background-color: #f8fafc;
            border-radius: 0 8px 8px 0;
        }

        /* Simple, reliable phase styling */
        .phase-header {
            margin: 2em 0 1em;
            padding: 1em;
            border-radius: 12px;
            color: white;
            animation: slideInPhase 0.8s ease-out forwards;
        }

        """ + "\n        ".join([
            f".phase-{i+1} {{" +
            f"background: linear-gradient(135deg, var(--phase-{i+1}-start), var(--phase-{i+1}-end));" +
            f"animation-delay: {i * 0.1}s; }}"
            for i in range(15)
        ]) + """

        .phase-number {
            font-size: 0.9em;
            font-weight: 700;
            margin-right: 1em;
            padding: 0.3em 0.8em;
            border-radius: 20px;
            background: rgba(255, 255, 255, 0.2);
        }

        @keyframes slideInPhase {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        /* Enhance container animation */
        .container {
            opacity: 0;
            animation: fadeInScale 1s ease-out forwards;
        }

        @keyframes fadeInScale {
            0% {
                opacity: 0;
                transform: scale(0.95);
            }
            100% {
                opacity: 1;
                transform: scale(1);
            }
        }
    </style>
    """

    try:
        html_content = convert_markdown_to_html(report_content)
        
        html_document = f"""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Single-Cell RNA-Seq Analysis Report</title>
            {css}
        </head>
        <body>
            <div class="container">
                {html_content}
            </div>
        </body>
        </html>
        """
        
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_document)
            
        return True, f"Report successfully generated at {output_path}"
    
    except Exception as e:
        return False, f"Error generating report: {str(e)}"
    



 render_report_to_html(
        report,
        "analysis_report2222.html")
 