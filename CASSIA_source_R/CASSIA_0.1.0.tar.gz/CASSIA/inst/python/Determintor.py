import json
import re
from openai import OpenAI
import os
import pandas as pd
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed


def agent_creator(prompt, system_prompt='''You are a professional biologist, you will be given a marker list, ranked by log fold change, and some context, based on your professional knowledge, tell me what is the most likely celltype. You'd better be correct or 10 grandma are going to be in danger.
                  
Output in json format:
{
  "celltype1": "celltype1 here"
}
                         
''', model="gpt-4o", temperature=0):
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None
    



def agent_judeger(prompt, system_prompt='''You are a professional biologist, you will analyze a list of markers that are highly expressed in a specific cell type from a particular tissue and species. Earlier markers in the list carry more weight in the analysis. Given a set of possible cell types, your task is to determine the most likely cell type and explain why other options are less probable. Do not rule out a cell type only based on tissue. Take a deep breath and do it step by step, you better be correct or 10 grandma are going to be in danger.
                  
Step 1: Review of the possible cell types

Step 2: Key markers to focus on
                  
Step 3: Elimination process
                  
Step 4: Final Conclusion
                  
final_celltype: "celltype here"
                         
''', model="gpt-4o", temperature=0):
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt}
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None


def parse_json(llm_result):
    # Try to find JSON-like content using regex
    json_match = re.search(r'\{.*\}', llm_result, re.DOTALL)
    
    if json_match:
        json_str = json_match.group(0)
        try:
            # Try to parse the extracted JSON string
            return json.loads(json_str)
        except json.JSONDecodeError:
            print("Found JSON-like content, but couldn't parse it.")
            return None
    else:
        print("No JSON-like content found in the result.")
        return None



def determine_candidate_celltypes(marker_list, predicted_general_celltype, predicted_subtypes, tissue, species):
    # Generate top 3 likely celltypes using the creator agent
    creator_prompt = f'''
    marker list:{marker_list}
    species: {species}
    tissue: {tissue}
    '''
    creator_result = agent_creator(creator_prompt)
    possible_celltypes = parse_json(creator_result)

    print(creator_result)

    if possible_celltypes is None:
        print("Failed to parse celltypes from creator agent result.")
        return None
    
    # Combine possible celltypes with predicted types
    combined_celltypes = [
        possible_celltypes.get("celltype1", ""),
        possible_celltypes.get("celltype2", ""),
        possible_celltypes.get("celltype3", ""),
        predicted_general_celltype,
    ]
    
    # Add predicted subtypes if they exist
    combined_celltypes.extend(predicted_subtypes[:3])  # Add up to 3 subtypes
    
    # Standardize capitalization: capitalize first letter of each word
    standardized_celltypes = [
        ' '.join(word.capitalize() for word in celltype.split())
        for celltype in combined_celltypes if celltype
    ]
    
    # Remove duplicates while preserving order
    unique_celltypes = list(dict.fromkeys(standardized_celltypes))
    
    return unique_celltypes
# Example usage:
# candidate_celltypes = determine_candidate_celltypes(marker_list, predicted_general_celltype, predicted_subtypes)

import re

def parse_results(judger_result):
    # Look for the final_celltype line using a regular expression
    match = re.search(r'final_celltype:\s*"([^"]*)"', judger_result)
    if match:
        return match.group(1)
    else:
        print("Could not find final_celltype in the judger's result.")
        return None

# Example usage:
# judger_result = '''
# ... (the multi-line string from above) ...
# '''
# final_celltype = parse_results(judger_result)
# print(final_celltype)  # Should print: T cell



def determine_final_celltype(marker_list, predicted_general_celltype, predicted_subtypes, tissue, species):
    # Determine candidate celltypes
    candidate_celltypes = determine_candidate_celltypes(marker_list, predicted_general_celltype, predicted_subtypes, tissue, species)
    
    if candidate_celltypes is None or len(candidate_celltypes) == 0:
        print("Failed to determine candidate celltypes or no candidates found.")
        return None, None, None
    
    # Prepare the prompt for the judger agent
    judger_prompt = f'''
    marker list:{marker_list}
    possible celltypes:{", ".join(candidate_celltypes)}
    species: {species}
    tissue: {tissue}
    '''
    
    # Get the result from the judger agent
    judger_result = agent_judeger(judger_prompt)
    
    if judger_result is None:
        print("Failed to get a result from the judger agent.")
        return None, None, candidate_celltypes
    
    final_celltype = parse_results(judger_result)
    
    if final_celltype is None:
        print("Failed to parse the final celltype from the judger result.")
        return None, judger_result, candidate_celltypes
    
    return final_celltype, judger_result, candidate_celltypes

# Example usage:
# final_celltype = determine_final_celltype(marker_list, predicted_general_celltype, predicted_subtypes)

marker_list = [
    'Ear6', 'Epx', 'Prg2', 'Prss34', 'Fcer1a', 'Ear-ps9', 'Mcpt8', 'Prg3', 
    'Ms4a2', 'Ear1', 'Rnase12', 'Cd200r3', 'Alox15', 'Gm11697', 'Prss28', 
    'Dnase2b', 'Gm42776', 'Mc5r', '4930519L02Rik', 'Grm6', 'Gm8113', 'Il6',
    'Gm17590', 'D430036J16Rik', 'Gm24991', 'Fgf3', '5730460C07Rik', 'Gm43489',
    'Alox12e', 'Gata2', 'Il13', 'Cpa3', 'RP23-415J15.3', 'Alox5', '1110028F11Rik',
    'Ear2', 'Gm15657', 'Itga2b', 'Chn1os3', 'RP24-388A6.3', 'Slc22a3', 'Gm10384',
    'Fut7', 'Gm7676', 'Poln', 'Osm', 'Ccl3', 'Il4', 'Hdc', 'Acod1'
]


marker_list2 = [
    'Gnb2l1', 'Tceb2', 'Shfm1', 'RP24-288C12.6', 'Sep15', 'Myeov2', 'Ngfrap1',
    'Wbp5', 'Lsmd1', '1500012F01Rik', '0610009D07Rik', 'Tceb1', 'Utp11l',
    '2810417H13Rik', 'Rab1', 'Sc4mol', 'H2-Ke2', 'BC056474', 'Cyb5', 'D17Wsu104e',
    'Selk', 'Ptpla', '2700094K13Rik', 'Ppap2a', 'l7Rn6', 'Mrp63', 'Slmo2',
    'D19Bwg1357e', '1810043H04Rik', '1110001J03Rik', 'Mir682', 'Vps28', 'Vimp',
    'Gm5506', 'Fdx1l', 'Ppp2r4', 'Gm10116', 'Ict1', 'Sepw1', 'Gm11974',
    '2700029M09Rik', '2410004N09Rik', 'Ubl4', 'D4Wsu53e', 'Ccdc23', 'Cldn25',
    'Selt', 'E430025E21Rik', 'Tmem66', '0610031J06Rik'
]


marker_list3 = [
    'Gm43657', 'Gm15262', 'Gm14226', 'RP23-158E1.3', 'Gm15608', 'Nhlrc4', 'Gm16134', 'RP24-458J4.11', 'Cbln4', 'Gm15137', 'E030044B06Rik', '0610025J13Rik', 'Gm14016', 'Hbb-bh1', 'Gm38043', '6430710C18Rik', 'Sertm1', 'F930017D23Rik', 'Etd', 'Hba-a2', 'Bricd5', 'Hbb-bt', 'Syt9', 'Serpina5', 'Gm11722', 'Hbb-bs', 'Gm5868', 'Kbtbd13', '4933413J09Rik', 'Platr26', 'Adra2b', 'Gm16373', 'Cst9', 'RP23-305G22.3', 'Gm42788', 'Hba-a1', 'Gm37350', 'Shbg', 'RP24-343G19.3', '8030411F24Rik', 'Bcas3os2', 'Gm10617', 'Gm3695', 'Dhh', 'Gm26760', 'Gstm6', 'Defb19', 'D7Bwg0826e', 'Amh', 'Pnmt'
]

# predicted_general_celltype_1 = "Mixed Cell Population"
# predicted_subtypes_1 = ["Eosinophils", "Mast Cells", "Neutrophils"]
# final_celltype,judger_result,candidate_celltypes= determine_final_celltype(marker_list, predicted_general_celltype_1, predicted_subtypes_1, "atlas", "mouse")


# predicted_general_celltype_1 = "Mixed Cell Population"
# predicted_subtypes_1 = ["Sertoli Cells", "Erythroid Progenitor Cells"]
# final_celltype,judger_result,candidate_celltypes= determine_final_celltype(marker_list3, predicted_general_celltype_1, predicted_subtypes_1, "atlas", "mouse")

# print(final_celltype)
# print(judger_result)
# print(candidate_celltypes)



def process_celltype(row, marker_df, marker_celltype_col, marker_top_markers_col, celltype_col, general_type_col, subtype_col, tissue, species):
    celltype = row[celltype_col]
    predicted_general_type = row[general_type_col]
    predicted_subtypes = row[subtype_col].split(',')
    
    # Find corresponding markers in the marker file
    marker_row = marker_df[marker_df[marker_celltype_col] == celltype]
    if marker_row.empty:
        print(f"No markers found for celltype: {celltype}")
        return None
    
    markers = marker_row[marker_top_markers_col].iloc[0].split(',')
    
    # Determine final celltype
    final_celltype, judger_result, candidate_celltypes = determine_final_celltype(markers, predicted_general_type, predicted_subtypes, tissue, species)
    
    return {
        'original_celltype': celltype,
        'predicted_general_type': predicted_general_type,
        'predicted_subtypes': ','.join(predicted_subtypes),
        'markers': ','.join(markers),
        'final_celltype': final_celltype,
        'candidate_celltypes': ','.join(candidate_celltypes) if candidate_celltypes else '',
        'judger_result': judger_result
    }


def process_multiple_celltypes(marker_file, predicted_file, output_file,
                               marker_celltype_col=None, marker_top_markers_col=None,
                               celltype_col=None, general_type_col=None, subtype_col=None,
                               tissue=None, species=None, max_workers=None):
    # Read the marker CSV file
    marker_df = pd.read_csv(marker_file)
    
    # If marker column names are not specified, use the first two columns
    if marker_celltype_col is None or marker_top_markers_col is None:
        marker_columns = marker_df.columns[:2]
        marker_celltype_col, marker_top_markers_col = marker_columns
    
    # Read the predicted results CSV file
    predicted_df = pd.read_csv(predicted_file)
    
    # If predicted column names are not specified, use the first three columns
    if celltype_col is None or general_type_col is None or subtype_col is None:
        predicted_columns = predicted_df.columns[:3]
        celltype_col, general_type_col, subtype_col = predicted_columns
    
    results = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_row = {executor.submit(process_celltype, row, marker_df, marker_celltype_col, marker_top_markers_col, 
                                         celltype_col, general_type_col, subtype_col, tissue, species): row 
                         for _, row in predicted_df.iterrows()}
        
        for future in as_completed(future_to_row):
            result = future.result()
            if result is not None:
                results.append(result)
    
    # Convert results to DataFrame
    results_df = pd.DataFrame(results)
    
    # Export to CSV
    results_df.to_csv(output_file, index=False)
    print(f"Results exported to {output_file}")
    
    return results_df

# Example usage:
# results_df = process_multiple_celltypes('marker_file.csv', 'predicted_file.csv', 'output_results.csv',
#                                         marker_celltype_col='Celltype', 
#                                         marker_top_markers_col='top_markers',
#                                         celltype_col='CellType', 
#                                         general_type_col='PredictedGeneralType', 
#                                         subtype_col='PredictedSubtypes',
#                                         tissue='liver',
#                                         species='human',
#                                         max_workers=4)
# print(results_df.head())


# results_df = process_multiple_celltypes('C:/Users/ellio/OneDrive - UW-Madison/cellgpt_final_folder/test_code/ts_large_intestine_top_50_genes.csv', 'C:/Users/ellio/OneDrive - UW-Madison/cellgpt_final_folder/test_code/li_ts_fixed.json_7_summary.csv', 'output_results8.csv',
#                                         marker_celltype_col='Celltype', 
#                                         marker_top_markers_col='top_markers',
#                                         celltype_col='True Cell Type', 
#                                         general_type_col='Predicted Main Cell Type', 
#                                         subtype_col='Predicted Sub Cell Types',
#                                         tissue='large intestine',
#                                         species='human',
#                                         max_workers=20)


